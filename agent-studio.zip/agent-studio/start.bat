@echo off
rem Agent Studio launcher for Windows. Double-click this file to start the server.
rem If a folder named "venv" exists next to this file, its Python is used automatically.
setlocal
title Agent Studio
cd /d "%~dp0"

set "PY="
set "PYARGS="
if exist "%~dp0venv\Scripts\python.exe" set "PY=%~dp0venv\Scripts\python.exe"

if not defined PY (
  python -c "import sys" >nul 2>nul && set "PY=python"
)
if not defined PY (
  py -3 -c "import sys" >nul 2>nul && set "PY=py" && set "PYARGS=-3"
)
if not defined PY (
  echo Python 3 was not found.
  echo Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
  pause
  exit /b 1
)

echo Using Python: %PY% %PYARGS%
echo Starting Agent Studio at http://127.0.0.1:8787
echo Keep this window open. Press Ctrl+C to stop the server.
echo.

rem Open the browser after a short delay so the server is ready.
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:8787"

"%PY%" %PYARGS% agent_server.py
echo.
echo Server stopped.
pause
