#!/usr/bin/env bash
# Agent Studio launcher for Linux and macOS.
# Usage: ./start.sh   (or: bash start.sh)
cd "$(dirname "$0")" || exit 1

PY=""
for c in python3 python; do
  if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' 2>/dev/null; then
    PY="$c"
    break
  fi
done
if [ -z "$PY" ]; then
  echo "Python 3.8 or newer was not found."
  echo "Install it with your package manager, for example: sudo apt install python3"
  exit 1
fi

URL="http://127.0.0.1:8787"
echo "Starting Agent Studio at $URL"
echo "Press Ctrl+C to stop the server."

# Open the browser after a short delay so the server is ready.
(
  sleep 2
  if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"
  elif command -v open >/dev/null 2>&1; then open "$URL"
  fi
) >/dev/null 2>&1 &

exec "$PY" agent_server.py
