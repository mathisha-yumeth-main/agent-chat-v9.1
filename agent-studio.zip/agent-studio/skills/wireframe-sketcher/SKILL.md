---
name: wireframe-sketcher
description: Sketch page layouts as simple wireframes.
---

# Wireframe Sketcher

## When to use
Sketch page layouts as simple wireframes.

## Steps
1. List the page's goal and main sections
2. Draw an SVG or ASCII wireframe with labeled boxes and priorities
3. Note what changes on mobile

## Output
Wireframe file and notes.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
