---
name: contract-summarizer
description: Summarize contracts in plain language.
---

# Contract Summarizer

## When to use
Summarize contracts in plain language.

## Steps
1. Read the whole text and list parties, term, payment, duties and exits
2. Flag unusual or one-sided clauses and missing items
3. State clearly this is a summary, not legal advice, and suggest a lawyer for decisions

## Output
Plain summary with flagged clauses.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
