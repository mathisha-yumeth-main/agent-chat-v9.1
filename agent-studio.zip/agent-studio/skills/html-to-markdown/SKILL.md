---
name: html-to-markdown
description: Convert HTML to Markdown.
---

# HTML To Markdown

## When to use
Convert HTML to Markdown.

## Steps
1. Use pandoc (`-f html -t gfm`) or a Python converter
2. Fix tables, code blocks and links that convert badly
3. Compare headings count with the source

## Output
Markdown file.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
