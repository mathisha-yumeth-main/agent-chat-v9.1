---
name: newsletter-writer
description: Write engaging newsletters.
---

# Newsletter Writer

## When to use
Write engaging newsletters.

## Steps
1. Ask for audience, goal and one main message
2. Write a subject line (give 3 options), a short intro, 2-3 sections and one call to action
3. Keep paragraphs short and cut anything that does not serve the main message

## Output
Full newsletter draft.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
