---
name: ssh-journal-reader
description: Query journalctl for a unit, priority or time window.
---

# SSH Journal Reader

## When to use
Query journalctl for a unit, priority or time window.

## Steps
1. Pick the unit and window (`--since "1 hour ago"`, `-b`, `-p err`)
2. Run `journalctl -u NAME --since ... --no-pager | tail -200`
3. Group repeated lines and find the FIRST error in the sequence
4. Explain the likely cause and the next check

## Output
Timeline of key log events with the probable root cause.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
