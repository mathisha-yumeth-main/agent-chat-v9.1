---
name: expense-categorizer
description: Categorize expenses from a CSV.
---

# Expense Categorizer

## When to use
Categorize expenses from a CSV.

## Steps
1. Read the CSV columns and a sample of rows
2. Assign categories by keywords and review the unclear ones with the user
3. Write a summary by category and month

## Output
Categorized CSV and summary.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
