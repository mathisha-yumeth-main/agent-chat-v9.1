---
name: svelte-builder
description: Build Svelte and SvelteKit components and pages.
---

# Svelte Builder

## When to use
Build Svelte and SvelteKit components and pages.

## Steps
1. Check `package.json` for Svelte version (runes in Svelte 5)
2. Keep components small, use stores or runes for state, and form actions in SvelteKit
3. Run `npm run check` and `npm run build`

## Output
Working Svelte component files.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
