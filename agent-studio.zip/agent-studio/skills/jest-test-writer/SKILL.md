---
name: jest-test-writer
description: Write Jest or Vitest tests for JavaScript and TypeScript.
---

# Jest Test Writer

## When to use
Write Jest or Vitest tests for JavaScript and TypeScript.

## Steps
1. Read the module and list inputs, outputs and failure cases
2. Use `describe`/`it`, mocks for I/O and `test.each` for tables
3. Run `npx jest` or `npx vitest run` and report the results

## Output
Test file that passes.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
