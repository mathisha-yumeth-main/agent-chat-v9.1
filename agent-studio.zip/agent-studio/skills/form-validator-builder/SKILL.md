---
name: form-validator-builder
description: Build accessible forms with validation.
---

# Form Validator Builder

## When to use
Build accessible forms with validation.

## Steps
1. Use proper `label`, `type`, `required` and `autocomplete` attributes
2. Validate on blur and submit; show clear messages tied with `aria-describedby`
3. Always validate again on the server

## Output
Form markup and validation code.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
