---
name: lora-finetune-planner
description: Plan LoRA fine-tuning of a small model.
---

# LoRA Finetune Planner

## When to use
Plan LoRA fine-tuning of a small model.

## Steps
1. Define the task and collect 200+ clean examples in one consistent format
2. Choose base model, rank (8-16), learning rate and epochs; keep a validation split
3. Plan evaluation before and after and how to merge or load the adapter

## Output
Training plan with settings and checks.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
