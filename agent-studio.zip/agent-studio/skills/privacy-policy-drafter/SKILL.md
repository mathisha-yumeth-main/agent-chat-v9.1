---
name: privacy-policy-drafter
description: Draft a privacy policy for a site or app.
---

# Privacy Policy Drafter

## When to use
Draft a privacy policy for a site or app.

## Steps
1. Ask what data is collected, why, who receives it and where it is stored
2. Write clear sections: data, purposes, sharing, retention, rights, contact
3. Say it is a template to be reviewed by a lawyer

## Output
Draft policy text.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
