---
name: pytest-fixture-writer
description: Write pytest tests with fixtures and parametrization.
---

# pytest Fixture Writer

## When to use
Write pytest tests with fixtures and parametrization.

## Steps
1. Read the code under test and list behaviors and edge cases
2. Create fixtures in `conftest.py`, use `parametrize` and `tmp_path`
3. Run `pytest -q` and fix failures in the tests or the code

## Output
Passing pytest file with clear test names.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
