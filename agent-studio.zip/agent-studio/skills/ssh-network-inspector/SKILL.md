---
name: ssh-network-inspector
description: Inspect a server's addresses, routes, DNS and open ports.
---

# SSH Network Inspector

## When to use
Inspect a server's addresses, routes, DNS and open ports.

## Steps
1. Run `ip -br addr; ip route; resolvectl status 2>/dev/null | head -20`
2. Check listeners with `ss -tulpn`
3. Test outbound with `curl -sS -o /dev/null -w "%{http_code}\n" https://example.com` and `getent hosts example.com`
4. Explain anything unusual such as unexpected open ports

## Output
Network summary with odd findings.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
