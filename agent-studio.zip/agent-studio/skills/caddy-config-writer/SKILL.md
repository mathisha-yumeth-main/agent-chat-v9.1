---
name: caddy-config-writer
description: Write Caddyfiles for sites and reverse proxies.
---

# Caddy Config Writer

## When to use
Write Caddyfiles for sites and reverse proxies.

## Steps
1. Use the short Caddyfile syntax: site address, `reverse_proxy`, `file_server`
2. Rely on Caddy's automatic HTTPS and mention the required DNS and ports
3. Validate with `caddy validate --config Caddyfile`

## Output
A Caddyfile and run instructions.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
