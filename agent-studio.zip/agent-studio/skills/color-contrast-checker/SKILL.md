---
name: color-contrast-checker
description: Check text and background contrast against WCAG.
---

# Color Contrast Checker

## When to use
Check text and background contrast against WCAG.

## Steps
1. Get the foreground and background colors
2. Compute the contrast ratio (luminance formula) and compare with 4.5:1 for normal text and 3:1 for large text
3. Suggest the nearest passing colors

## Output
Pass/fail table with fixes.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
