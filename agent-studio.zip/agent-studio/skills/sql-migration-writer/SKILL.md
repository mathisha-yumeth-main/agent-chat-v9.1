---
name: sql-migration-writer
description: Write safe database schema migrations.
---

# SQL Migration Writer

## When to use
Write safe database schema migrations.

## Steps
1. Describe the current and target schema
2. Write up and down steps; add columns as nullable first and backfill in batches
3. Warn about locks on big tables and test on a copy

## Output
Migration files with a rollback.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
