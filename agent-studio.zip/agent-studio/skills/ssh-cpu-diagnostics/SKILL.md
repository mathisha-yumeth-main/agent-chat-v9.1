---
name: ssh-cpu-diagnostics
description: Find what causes high CPU or load on a server.
---

# SSH CPU Diagnostics

## When to use
Find what causes high CPU or load on a server.

## Steps
1. Run `uptime; nproc; top -bn1 | head -15`
2. List top processes with `ps aux --sort=-%cpu | head -15`
3. Check iowait with `vmstat 1 5` (and `iostat -x 1 3` if installed)
4. State whether the load is CPU, disk or memory bound

## Output
Bottleneck verdict with evidence.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
