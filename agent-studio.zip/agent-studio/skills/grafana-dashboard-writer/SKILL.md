---
name: grafana-dashboard-writer
description: Design Grafana dashboards.
---

# Grafana Dashboard Writer

## When to use
Design Grafana dashboards.

## Steps
1. List the questions the dashboard must answer
2. Create panels with PromQL or SQL queries, units and thresholds
3. Export as JSON and check variables and time ranges

## Output
Dashboard JSON and a panel list.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
