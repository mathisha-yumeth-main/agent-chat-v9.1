---
name: sprint-planner
description: Plan a sprint from a backlog.
---

# Sprint Planner

## When to use
Plan a sprint from a backlog.

## Steps
1. List the candidate items with estimates
2. Fit the team's capacity, keep 15-20% buffer and include bugs
3. State the sprint goal and the items to cut first if time runs out

## Output
Sprint plan with goal.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
