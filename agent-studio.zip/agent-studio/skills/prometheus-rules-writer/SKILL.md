---
name: prometheus-rules-writer
description: Write Prometheus alert and recording rules.
---

# Prometheus Rules Writer

## When to use
Write Prometheus alert and recording rules.

## Steps
1. Pick the metric and the failure condition in plain words
2. Write PromQL with `rate()` windows, `for:` durations and useful labels
3. Add summary and runbook annotations and check with `promtool check rules`

## Output
Rules file with explanations.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
