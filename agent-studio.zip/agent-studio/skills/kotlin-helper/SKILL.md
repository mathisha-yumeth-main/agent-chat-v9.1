---
name: kotlin-helper
description: Write Kotlin for JVM, Android or scripts.
---

# Kotlin Helper

## When to use
Write Kotlin for JVM, Android or scripts.

## Steps
1. Check build files (Gradle Kotlin DSL) and the target (JVM or Android)
2. Use data classes, null safety and coroutines instead of Java-style code
3. Run the Gradle test task and explain compiler errors

## Output
Idiomatic Kotlin with a short explanation.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
