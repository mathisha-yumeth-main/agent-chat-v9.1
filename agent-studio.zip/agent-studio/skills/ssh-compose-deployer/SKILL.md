---
name: ssh-compose-deployer
description: Deploy or update a Docker Compose stack on a server.
---

# SSH Compose Deployer

## When to use
Deploy or update a Docker Compose stack on a server.

## Steps
1. Find the project folder and read docker-compose.yml first
2. Validate with `docker compose config -q`
3. Run `docker compose pull && docker compose up -d` for one project at a time
4. Check `docker compose ps` and the logs for 30 seconds

## Output
Stack status and the rollback command.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
