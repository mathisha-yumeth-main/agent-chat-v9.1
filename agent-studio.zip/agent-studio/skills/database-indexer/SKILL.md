---
name: database-indexer
description: Choose and test database indexes.
---

# Database Indexer

## When to use
Choose and test database indexes.

## Steps
1. Collect the slowest queries and their filters, joins and sorts
2. Propose composite indexes in the right column order and avoid duplicates
3. Measure with `EXPLAIN` and note write-cost trade-offs

## Output
Index list with expected benefit.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
