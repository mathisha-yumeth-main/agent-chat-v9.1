---
name: agent-tool-designer
description: Design tools and schemas for AI agents.
---

# Agent Tool Designer

## When to use
Design tools and schemas for AI agents.

## Steps
1. List the actions the agent needs and keep each tool narrow
2. Define names, JSON-schema arguments and clear error messages
3. Add safety: confirmation for destructive actions and size limits on output

## Output
Tool spec list with schemas.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
