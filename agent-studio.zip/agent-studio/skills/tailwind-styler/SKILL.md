---
name: tailwind-styler
description: Style pages with Tailwind CSS utility classes.
---

# Tailwind Styler

## When to use
Style pages with Tailwind CSS utility classes.

## Steps
1. Check whether Tailwind is installed (config file, `@tailwind` directives) or use the CDN for a quick page
2. Use responsive prefixes (`sm:`, `md:`), spacing scale and `dark:` variants; extract repeated groups into components
3. Verify at mobile and desktop widths

## Output
Tailwind-styled markup that is responsive.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
