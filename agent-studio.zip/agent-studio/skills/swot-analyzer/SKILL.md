---
name: swot-analyzer
description: Create SWOT analyses.
---

# SWOT Analyzer

## When to use
Create SWOT analyses.

## Steps
1. Ask for the subject and context
2. List strengths and weaknesses (internal) and opportunities and threats (external), with evidence
3. Turn the top items into 3 concrete actions

## Output
SWOT grid and actions.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
