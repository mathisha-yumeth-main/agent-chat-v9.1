---
name: uuid-generator
description: Generate UUIDs and unique IDs.
---

# UUID Generator

## When to use
Generate UUIDs and unique IDs.

## Steps
1. Use Python `uuid.uuid4()` for random IDs and `uuid7` style or ULIDs when sorting matters
2. Explain collisions and when sequential IDs are better
3. Return the requested count

## Output
List of IDs.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
