---
name: worldbuilding-helper
description: Build fictional worlds.
---

# Worldbuilding Helper

## When to use
Build fictional worlds.

## Steps
1. Define the core idea, geography, cultures, magic or technology and conflicts
2. Make rules consistent and note their consequences
3. Produce a world bible with names and a timeline

## Output
World document.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
