---
name: meal-planner
description: Plan weekly meals and shopping lists.
---

# Meal Planner

## When to use
Plan weekly meals and shopping lists.

## Steps
1. Ask about diet, allergies, budget, time and servings
2. Plan 7 days with simple recipes and reuse of ingredients
3. Produce a grocery list grouped by store section

## Output
Meal plan and shopping list.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
