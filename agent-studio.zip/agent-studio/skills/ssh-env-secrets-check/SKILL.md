---
name: ssh-env-secrets-check
description: Look for exposed secrets on a server without printing them.
---

# SSH Env Secrets Check

## When to use
Look for exposed secrets on a server without printing them.

## Steps
1. Search names only: `grep -rIl -E "(api[_-]?key|secret|password|token)\s*=" /var/www /home 2>/dev/null | head`
2. Check each hit with `ls -l`
3. Report file names and the risk; never print secret values
4. Recommend env files with mode 600

## Output
List of risky files and how to fix each.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
