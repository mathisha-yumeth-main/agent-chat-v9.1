---
name: web-performance-tuner
description: Speed up a web page.
---

# Web Performance Tuner

## When to use
Speed up a web page.

## Steps
1. Look for large images, render-blocking scripts and unused CSS or JS
2. Apply fixes: compress and resize images, `loading="lazy"`, `defer`, caching headers
3. Re-measure file sizes and report the change

## Output
Prioritized fixes with expected gains.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
