---
name: ssh-package-updater
description: Plan and run safe package updates on a server.
---

# SSH Package Updater

## When to use
Plan and run safe package updates on a server.

## Steps
1. Detect the manager (apt, dnf, yum, pacman, apk)
2. List what would change (`apt list --upgradable` or `dnf check-update`)
3. Flag kernel, database and ssh updates and ask before applying
4. Apply, then check `systemctl --failed` and whether /var/run/reboot-required exists

## Output
Update list, risks, result and whether a reboot is needed.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
