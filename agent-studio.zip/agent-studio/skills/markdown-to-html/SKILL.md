---
name: markdown-to-html
description: Convert Markdown to clean HTML pages.
---

# Markdown To HTML

## When to use
Convert Markdown to clean HTML pages.

## Steps
1. Use pandoc if available or Python's `markdown` library
2. Wrap in a template with readable CSS and a responsive width
3. Check links and headings in the output

## Output
HTML file.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
