---
name: ruby-developer
description: Write idiomatic Ruby scripts and gems.
---

# Ruby Developer

## When to use
Write idiomatic Ruby scripts and gems.

## Steps
1. Check `ruby -v` and the Gemfile
2. Use blocks, `Enumerable` methods and small classes; add a `# frozen_string_literal: true` header
3. Test with RSpec or Minitest and lint with RuboCop if present

## Output
Ruby code with tests.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
