---
name: ocr-extractor
description: Extract text from images and scans.
---

# OCR Extractor

## When to use
Extract text from images and scans.

## Steps
1. Check for `tesseract` with `tesseract --version` and pytesseract
2. Preprocess: grayscale, resize, threshold when quality is low
3. Run OCR, save text to a file and flag low-confidence parts

## Output
Extracted text file and accuracy notes.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
