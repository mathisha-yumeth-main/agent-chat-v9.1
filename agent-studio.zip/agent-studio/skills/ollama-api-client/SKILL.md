---
name: ollama-api-client
description: Call the Ollama HTTP API from code.
---

# Ollama API Client

## When to use
Call the Ollama HTTP API from code.

## Steps
1. Use `POST /api/chat` with `model`, `messages` and `stream`; handle streaming lines of JSON
2. Use `/api/tags` to list models and `/api/embeddings` for vectors
3. Handle connection errors with a clear message

## Output
Client code with streaming support.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
