---
name: matplotlib-plotter
description: Make clear charts with Matplotlib.
---

# Matplotlib Plotter

## When to use
Make clear charts with Matplotlib.

## Steps
1. Pick a chart that matches the data and label axes and units
2. Use `plt.subplots`, readable fonts and `tight_layout`
3. Save with `plt.savefig(FILE, dpi=150)` into the workspace

## Output
PNG chart and the script.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
