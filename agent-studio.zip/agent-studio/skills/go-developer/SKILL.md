---
name: go-developer
description: Write, run and test Go programs and modules.
---

# Go Developer

## When to use
Write, run and test Go programs and modules.

## Steps
1. Check `go version`; use `go mod init` and keep code in packages with small functions
2. Handle every error explicitly and format with `gofmt`
3. Write table-driven tests and run `go vet ./...` and `go test ./...`

## Output
Working Go code with tests and the commands to run it.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
