---
name: budget-planner
description: Build a monthly budget.
---

# Budget Planner

## When to use
Build a monthly budget.

## Steps
1. List income and fixed and variable expenses
2. Apply a simple rule (e.g. 50/30/20) and adjust to the user's goals
3. Create a spreadsheet-friendly CSV with totals

## Output
Budget table and savings amount.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
