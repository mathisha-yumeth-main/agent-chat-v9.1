---
name: business-plan-outliner
description: Outline a business plan.
---

# Business Plan Outliner

## When to use
Outline a business plan.

## Steps
1. Collect the idea, customers, offer and money flow
2. Outline problem, solution, market, competitors, model, marketing, operations and finances
3. Mark assumptions to verify

## Output
Plan outline with open questions.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
