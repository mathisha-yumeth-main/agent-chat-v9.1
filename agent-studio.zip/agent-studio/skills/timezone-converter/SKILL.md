---
name: timezone-converter
description: Convert times between time zones.
---

# Timezone Converter

## When to use
Convert times between time zones.

## Steps
1. Identify the source zone and the target zones (use IANA names)
2. Convert with Python `zoneinfo` to handle daylight saving
3. Show a table of local times

## Output
Conversion table.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
