---
name: ffmpeg-command-builder
description: Build ffmpeg commands for video and audio tasks.
---

# ffmpeg Command Builder

## When to use
Build ffmpeg commands for video and audio tasks.

## Steps
1. Ask for input, output format and the goal (convert, trim, compress, extract audio)
2. Write the exact command with explanations, e.g. `-ss`, `-t`, `-crf`, `-vf scale`
3. Never overwrite files without `-n` or the user's approval

## Output
Copy-ready ffmpeg command and an explanation.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
