---
name: prompt-engineer
description: Write and improve prompts for language models.
---

# Prompt Engineer

## When to use
Write and improve prompts for language models.

## Steps
1. Define the task, audience, format and success checks
2. Write a clear prompt with role, context, rules and 1-2 examples; ask for structured output when needed
3. Test on 3 inputs including a tricky one and refine

## Output
Final prompt plus test results.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
