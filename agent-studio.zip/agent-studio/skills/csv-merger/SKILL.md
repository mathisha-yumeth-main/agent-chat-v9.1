---
name: csv-merger
description: Merge CSV files safely.
---

# CSV Merger

## When to use
Merge CSV files safely.

## Steps
1. Compare headers across files and note differences
2. Merge with pandas using `concat` or `merge` on a key and keep the source file name column
3. Report row counts in and out and any duplicates

## Output
Merged CSV and a row-count report.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
