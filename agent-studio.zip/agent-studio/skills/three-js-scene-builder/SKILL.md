---
name: three-js-scene-builder
description: Build 3D scenes with Three.js in one HTML file.
---

# Three.js Scene Builder

## When to use
Build 3D scenes with Three.js in one HTML file.

## Steps
1. Load Three.js from a CDN module and create scene, camera, renderer and a resize handler
2. Add lights, meshes and an animation loop with `requestAnimationFrame`
3. Use OrbitControls only when the import is available

## Output
A single HTML file that renders a 3D scene.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
