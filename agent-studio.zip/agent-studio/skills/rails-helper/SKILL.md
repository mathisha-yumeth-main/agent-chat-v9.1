---
name: rails-helper
description: Build Rails models, controllers, views and migrations.
---

# Rails Helper

## When to use
Build Rails models, controllers, views and migrations.

## Steps
1. Read `config/routes.rb` and `db/schema.rb` first
2. Use generators, strong parameters and scopes; keep controllers thin
3. Run `bin/rails db:migrate` and `bin/rails test` after confirming with the user

## Output
Rails changes consistent with the app.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
