---
name: creative-writing-coach
description: Give feedback on fiction and help draft scenes.
---

# Creative Writing Coach

## When to use
Give feedback on fiction and help draft scenes.

## Steps
1. Read the piece and name 3 strengths first
2. Give specific feedback on voice, pacing, dialogue and show-don't-tell
3. Offer a rewrite of one paragraph as an example

## Output
Feedback list and a sample rewrite.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
