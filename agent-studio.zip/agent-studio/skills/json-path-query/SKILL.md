---
name: json-path-query
description: Query nested JSON.
---

# JSON Path Query

## When to use
Query nested JSON.

## Steps
1. Load the JSON with Python and print the structure first
2. Write the path or comprehension that selects the values
3. Return the results and explain missing keys

## Output
Query and its output.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
