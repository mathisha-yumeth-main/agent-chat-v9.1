---
name: c-developer
description: Write careful C code and find memory bugs.
---

# C Developer

## When to use
Write careful C code and find memory bugs.

## Steps
1. Compile with `gcc -Wall -Wextra -g`
2. Check every allocation, buffer size and `free`; avoid unsafe functions like `gets` and unbounded `strcpy`
3. Use `valgrind` or `-fsanitize=address` when available and fix what it reports

## Output
C code that compiles clean, with memory issues explained.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
