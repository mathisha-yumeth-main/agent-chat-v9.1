---
name: gitlab-ci-writer
description: Write .gitlab-ci.yml pipelines.
---

# GitLab CI Writer

## When to use
Write .gitlab-ci.yml pipelines.

## Steps
1. Define stages (build, test, deploy) and the runner image
2. Use `cache`, `artifacts`, `rules` and protected variables for secrets
3. Lint the file with the CI Lint tool or `glab ci lint`

## Output
A working pipeline file.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
