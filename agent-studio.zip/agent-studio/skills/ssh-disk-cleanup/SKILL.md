---
name: ssh-disk-cleanup
description: Find what fills a remote disk and propose a safe cleanup.
---

# SSH Disk Cleanup

## When to use
Find what fills a remote disk and propose a safe cleanup.

## Steps
1. Run `df -h` and `du -xh --max-depth=1 / 2>/dev/null | sort -h | tail -15`
2. Drill into the largest folder the same way until the culprits are clear
3. Check `journalctl --disk-usage`, /var/log, package caches and `docker system df`
4. Propose deletions with sizes and wait for approval before removing anything

## Output
Table of space hogs with sizes and a cleanup plan.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
