---
name: rag-pipeline-builder
description: Build a retrieval-augmented generation pipeline.
---

# RAG Pipeline Builder

## When to use
Build a retrieval-augmented generation pipeline.

## Steps
1. Plan: load documents, split into chunks (300-800 tokens, small overlap), embed, store, retrieve, answer
2. Use a local embedding model via Ollama or an API; keep sources with each chunk
3. Make the answer cite chunk sources and say when nothing relevant is found

## Output
Working pipeline code with a test question.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
