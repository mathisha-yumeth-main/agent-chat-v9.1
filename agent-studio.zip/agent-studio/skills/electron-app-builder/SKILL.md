---
name: electron-app-builder
description: Build desktop apps with Electron.
---

# Electron App Builder

## When to use
Build desktop apps with Electron.

## Steps
1. Create `main.js`, `preload.js` and the renderer page; keep `contextIsolation` on and `nodeIntegration` off
2. Expose only needed APIs through `contextBridge`
3. Run with `npx electron .` and package with `electron-builder` when asked

## Output
Minimal Electron app that launches.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
