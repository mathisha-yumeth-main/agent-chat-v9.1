---
name: vocabulary-builder
description: Build vocabulary lists with examples.
---

# Vocabulary Builder

## When to use
Build vocabulary lists with examples.

## Steps
1. Ask for the topic and level
2. List words with meaning, example sentence and a memory tip
3. Create a short review quiz

## Output
Vocabulary table and quiz.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
