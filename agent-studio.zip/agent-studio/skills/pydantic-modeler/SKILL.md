---
name: pydantic-modeler
description: Model and validate data with Pydantic.
---

# Pydantic Modeler

## When to use
Model and validate data with Pydantic.

## Steps
1. Define `BaseModel` classes with types, defaults and `Field` constraints
2. Add validators for rules across fields and use `model_dump()` for output
3. Test with valid and invalid samples and show the error messages

## Output
Models plus a test of good and bad input.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
