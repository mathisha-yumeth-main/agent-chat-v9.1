---
name: ssh-nginx-deployer
description: Publish a site or reverse proxy with nginx on a server.
---

# SSH nginx Deployer

## When to use
Publish a site or reverse proxy with nginx on a server.

## Steps
1. Check `nginx -v; sudo nginx -t` and look at /etc/nginx/sites-enabled
2. Write a new server block in sites-available and symlink it; never overwrite an existing site
3. Run `sudo nginx -t` and only then `sudo systemctl reload nginx`
4. Test with `curl -I http://localhost`

## Output
Config written, test output and the URL to open.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
