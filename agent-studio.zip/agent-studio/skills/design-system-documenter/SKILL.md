---
name: design-system-documenter
description: Document colors, type and components of a design system.
---

# Design System Documenter

## When to use
Document colors, type and components of a design system.

## Steps
1. Extract tokens (colors, spacing, fonts) from the CSS
2. Describe each component's variants, states and usage rules
3. Write one page with copy-ready code examples

## Output
Design system page in Markdown or HTML.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
