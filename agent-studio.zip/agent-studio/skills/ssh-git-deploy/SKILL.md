---
name: ssh-git-deploy
description: Update a deployed app from git on a server and restart it.
---

# SSH Git Deploy

## When to use
Update a deployed app from git on a server and restart it.

## Steps
1. In the app folder run `git status --short; git log -1 --oneline`
2. Preview with `git fetch` and `git log HEAD..origin/BRANCH --oneline`
3. Run `git pull --ff-only`, reinstall dependencies if lockfiles changed, restart the service
4. Verify health and give the previous commit id as the rollback point

## Output
Old and new commit, restart result, rollback command.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
