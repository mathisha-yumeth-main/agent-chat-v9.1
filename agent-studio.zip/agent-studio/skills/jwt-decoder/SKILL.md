---
name: jwt-decoder
description: Decode and inspect JWTs.
---

# JWT Decoder

## When to use
Decode and inspect JWTs.

## Steps
1. Split on dots and Base64URL-decode header and payload with Python
2. Explain claims (`exp`, `iat`, `iss`, `sub`) and convert times
3. State that decoding does not verify the signature, and never paste live production tokens

## Output
Readable header, claims and expiry.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
