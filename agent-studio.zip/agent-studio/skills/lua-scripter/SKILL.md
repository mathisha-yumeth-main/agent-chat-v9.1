---
name: lua-scripter
description: Write Lua scripts for games, Neovim and embedded use.
---

# Lua Scripter

## When to use
Write Lua scripts for games, Neovim and embedded use.

## Steps
1. Ask for the host (LÖVE, Neovim, Roblox-style Luau, OpenResty)
2. Use local variables, tables as modules and avoid globals
3. Run with `lua FILE.lua` when available and test edge cases

## Output
A small Lua module with usage example.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
