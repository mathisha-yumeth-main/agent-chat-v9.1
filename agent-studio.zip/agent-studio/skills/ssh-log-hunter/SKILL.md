---
name: ssh-log-hunter
description: Search remote log files for errors, IPs or patterns.
---

# SSH Log Hunter

## When to use
Search remote log files for errors, IPs or patterns.

## Steps
1. List candidates with `ls -lt /var/log | head -30`
2. Search with `grep -iE "error|fail|denied" FILE | tail -100` and `zgrep` for rotated .gz files
3. Count patterns with `sort | uniq -c | sort -rn | head`
4. Report top findings with file and line evidence

## Output
Ranked findings with counts and sample lines.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
