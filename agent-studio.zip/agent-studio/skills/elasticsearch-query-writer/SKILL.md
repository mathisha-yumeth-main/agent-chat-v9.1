---
name: elasticsearch-query-writer
description: Write Elasticsearch queries and mappings.
---

# Elasticsearch Query Writer

## When to use
Write Elasticsearch queries and mappings.

## Steps
1. Define the mapping (keyword vs text) before indexing
2. Use `bool` queries with `must`, `filter` and `should`; add aggregations when needed
3. Test with the `_search` API and tune relevance

## Output
Mapping and query JSON.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
