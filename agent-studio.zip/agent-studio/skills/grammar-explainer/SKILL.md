---
name: grammar-explainer
description: Explain grammar rules clearly.
---

# Grammar Explainer

## When to use
Explain grammar rules clearly.

## Steps
1. Name the rule in plain words
2. Show 3 correct examples and 2 common mistakes
3. Give a short exercise with answers

## Output
Rule card and exercise.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
