---
name: coding-interview-coach
description: Practice coding interview problems.
---

# Coding Interview Coach

## When to use
Practice coding interview problems.

## Steps
1. Pick a problem by topic and difficulty
2. Let the user think first; give hints in stages, then the solution with complexity
3. Run the solution in Python against test cases

## Output
Problem, hints, solution and complexity.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
