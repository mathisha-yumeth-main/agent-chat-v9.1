---
name: ssh-database-backup
description: Dump a MySQL or PostgreSQL database on a server.
---

# SSH Database Backup

## When to use
Dump a MySQL or PostgreSQL database on a server.

## Steps
1. Identify the engine: `systemctl status mysql postgresql --no-pager`
2. Use `mysqldump --single-transaction DB | gzip > FILE` or `pg_dump -Fc DB > FILE`; never put a password on the command line
3. Check the dump: `ls -lh` and `gzip -t`
4. Tell the user where it is and how to restore it

## Output
Dump path, size and restore command.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
