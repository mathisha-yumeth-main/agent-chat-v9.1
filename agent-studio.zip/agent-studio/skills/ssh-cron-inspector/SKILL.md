---
name: ssh-cron-inspector
description: List every cron job and systemd timer on a server.
---

# SSH Cron Inspector

## When to use
List every cron job and systemd timer on a server.

## Steps
1. Run `crontab -l; sudo cat /etc/crontab; sudo ls /etc/cron.d /etc/cron.daily`
2. List timers with `systemctl list-timers --all --no-pager`
3. Check other users with `sudo ls /var/spool/cron/crontabs 2>/dev/null`
4. Explain each schedule in plain words and flag overlaps or failing jobs

## Output
Schedule table: when, who, what.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
