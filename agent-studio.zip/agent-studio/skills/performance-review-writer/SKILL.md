---
name: performance-review-writer
description: Write fair performance reviews.
---

# Performance Review Writer

## When to use
Write fair performance reviews.

## Steps
1. Collect achievements, evidence and goals
2. Write strengths and growth areas with specific examples
3. End with next-period goals and support

## Output
Review draft.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
