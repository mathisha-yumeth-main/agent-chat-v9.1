---
name: ssh-systemd-unit-writer
description: Write a systemd service or timer on a server.
---

# SSH Systemd Unit Writer

## When to use
Write a systemd service or timer on a server.

## Steps
1. Ask for the command, user, working folder and restart policy
2. Draft `[Unit]`, `[Service]` (User, WorkingDirectory, ExecStart, Restart=on-failure) and `[Install]`
3. Install to /etc/systemd/system/NAME.service, then `systemctl daemon-reload` and `enable --now`
4. Check `systemctl status` and `journalctl -u NAME`

## Output
The unit file and verification output.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
