---
name: sqlalchemy-helper
description: Write SQLAlchemy models, sessions and queries.
---

# SQLAlchemy Helper

## When to use
Write SQLAlchemy models, sessions and queries.

## Steps
1. Check the version (2.x uses `select()` and `Session`)
2. Define models with relationships and indexes; use sessions in a context manager
3. Test against SQLite first and show the generated SQL when helpful

## Output
Models and example queries that run.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
