---
name: model-quantization-guide
description: Choose quantization levels for local models.
---

# Model Quantization Guide

## When to use
Choose quantization levels for local models.

## Steps
1. Ask for the available RAM/VRAM and the speed or quality goal
2. Explain Q4_K_M, Q5_K_M, Q8_0 and FP16 trade-offs with approximate sizes
3. Recommend a model size and quant that fits with room for context

## Output
Recommendation with memory estimate.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
