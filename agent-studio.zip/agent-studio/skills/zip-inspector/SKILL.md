---
name: zip-inspector
description: Inspect archives without extracting them blindly.
---

# Zip Inspector

## When to use
Inspect archives without extracting them blindly.

## Steps
1. List contents with `unzip -l` or Python `zipfile`
2. Check for path traversal (`..`), huge expansion and executables
3. Extract only the needed files into a temp folder

## Output
Content list and a safety verdict.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
