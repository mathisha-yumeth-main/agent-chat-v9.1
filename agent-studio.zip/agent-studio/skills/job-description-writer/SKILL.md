---
name: job-description-writer
description: Write clear job descriptions.
---

# Job Description Writer

## When to use
Write clear job descriptions.

## Steps
1. Ask for the role, level, team and must-have skills
2. Write a short intro, responsibilities, requirements and nice-to-haves
3. Remove biased or inflated wording

## Output
Job post ready to publish.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
