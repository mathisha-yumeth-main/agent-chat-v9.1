---
name: ssh-sshd-hardening
description: Review sshd settings and suggest safer ones.
---

# SSH Sshd Hardening

## When to use
Review sshd settings and suggest safer ones.

## Steps
1. Read effective settings: `sudo sshd -T | grep -Ei "permitrootlogin|passwordauth|pubkeyauth|port|maxauthtries|allowusers"`
2. Compare with good practice (no root login, key auth, limited users)
3. Warn that disabling password login can lock the user out; confirm keys work first
4. Test with `sudo sshd -t` before any reload

## Output
Setting-by-setting review and a safe change order.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
