---
name: okr-planner
description: Write objectives and key results.
---

# OKR Planner

## When to use
Write objectives and key results.

## Steps
1. Ask for the goal and the time frame
2. Write 1-3 objectives with 2-4 measurable key results each (number, baseline, target)
3. Check that results are outcomes, not tasks

## Output
OKR table.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
