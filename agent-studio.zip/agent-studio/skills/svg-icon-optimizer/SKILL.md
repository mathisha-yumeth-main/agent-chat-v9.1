---
name: svg-icon-optimizer
description: Clean up and shrink SVG icons.
---

# SVG Icon Optimizer

## When to use
Clean up and shrink SVG icons.

## Steps
1. Remove metadata, comments and unused groups; keep `viewBox`
2. Use `currentColor` for fills so themes work
3. Compare sizes before and after and check it still renders

## Output
Optimized SVG and size change.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
