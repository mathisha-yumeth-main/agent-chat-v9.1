---
name: imagemagick-helper
description: Edit images in bulk with ImageMagick.
---

# ImageMagick Helper

## When to use
Edit images in bulk with ImageMagick.

## Steps
1. Check `magick -version` (or `convert -version`)
2. Build commands for resize, crop, convert and montage
3. Test on one copy first, then run on the folder

## Output
Command and a before/after check.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
