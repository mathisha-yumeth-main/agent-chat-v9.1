---
name: faq-writer
description: Write FAQ sections.
---

# FAQ Writer

## When to use
Write FAQ sections.

## Steps
1. Collect real customer questions or infer the top 8-10
2. Answer in 2-4 sentences each, with the answer first
3. Group by topic and mark where a link is needed

## Output
FAQ list ready to paste.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
