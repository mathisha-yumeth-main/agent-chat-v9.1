---
name: ssh-file-transfer-planner
description: Move files to or from a server (small via ssh, big via scp).
---

# SSH File Transfer Planner

## When to use
Move files to or from a server (small via ssh, big via scp).

## Steps
1. For small text files read with `cat` and write with a `cat > PATH <<'EOF'` heredoc
2. For binary or large files write the exact `scp` or `rsync -avP` command for the user to run
3. Check free space on the target with `df -h`
4. Verify with `sha256sum` on both sides

## Output
Method, command and checksum comparison.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
