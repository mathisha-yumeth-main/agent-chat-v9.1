---
name: poem-writer
description: Write original poems in chosen forms.
---

# Poem Writer

## When to use
Write original poems in chosen forms.

## Steps
1. Ask for theme, mood and form (free verse, sonnet, haiku, limerick)
2. Use concrete images and keep to the form's rules
3. Offer a second take with a different tone

## Output
Original poem, never copied lyrics.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
