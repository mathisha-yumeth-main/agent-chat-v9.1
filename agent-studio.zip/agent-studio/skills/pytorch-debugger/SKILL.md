---
name: pytorch-debugger
description: Debug PyTorch code.
---

# PyTorch Debugger

## When to use
Debug PyTorch code.

## Steps
1. Print tensor shapes and dtypes at each step; check `.to(device)`
2. Check loss goes down on a tiny batch before scaling up
3. Fix common causes: missing `zero_grad`, wrong loss input, eval mode, detach

## Output
Found bug and fix.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
