# 350 Skills — Folder-Ready Pack

This folder contains 350 individual skill folders (50 generic starters, 100 task-specific skills, and 200 more with concrete steps, including 33 server-administration skills that work over SSH). Each folder contains a `SKILL.md` file with YAML frontmatter (`name`, `description`) and instructions.

## Install
1. Extract the ZIP.
2. Copy the skill folders directly into your application's skills directory.
3. Restart or refresh the application if it loads skills only at startup.

Expected layout:
```
skills/
  file-manager/
    SKILL.md
  terminal-runner/
    SKILL.md
  ...
```

## Compatibility note
This is a generic folder-based skill format. Some applications expect a different filename or metadata schema; check your app's skill loader requirements if these folders are not detected. Skill descriptions do not create tool integrations by themselves: a host app must implement or expose the relevant tools. Destructive actions and system commands should require confirmation and be sandboxed.
