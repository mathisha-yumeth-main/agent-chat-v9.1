---
name: llm-evaluator
description: Evaluate model answers with a repeatable test set.
---

# LLM Evaluator

## When to use
Evaluate model answers with a repeatable test set.

## Steps
1. Write 20+ test prompts with expected facts or checks
2. Run each model on the same prompts and store the answers in a file
3. Score with simple rules first, then rubric review; compare in a table

## Output
Results table and a recommendation.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
