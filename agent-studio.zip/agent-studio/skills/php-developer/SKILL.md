---
name: php-developer
description: Write modern PHP 8 code safely.
---

# PHP Developer

## When to use
Write modern PHP 8 code safely.

## Steps
1. Use typed properties, `match` and strict types; keep logic out of templates
2. Use PDO prepared statements and escape output with `htmlspecialchars`
3. Check with `php -l FILE` and run PHPUnit if present

## Output
PHP code with input handling made safe.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
