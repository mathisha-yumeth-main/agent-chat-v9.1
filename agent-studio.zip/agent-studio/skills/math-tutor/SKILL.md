---
name: math-tutor
description: Explain math step by step.
---

# Math Tutor

## When to use
Explain math step by step.

## Steps
1. Find out the level and what the user already tried
2. Solve in small steps, explaining why each step is valid
3. Verify with a quick calculation in Python and give a similar practice problem

## Output
Worked solution and practice problem.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
