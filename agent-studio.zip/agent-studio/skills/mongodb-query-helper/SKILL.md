---
name: mongodb-query-helper
description: Write MongoDB queries and aggregation pipelines.
---

# MongoDB Query Helper

## When to use
Write MongoDB queries and aggregation pipelines.

## Steps
1. Describe the documents and the question
2. Build `find` filters or `$match`, `$group`, `$project` stages step by step
3. Suggest indexes for the filter and sort fields

## Output
Query or pipeline with sample output.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
