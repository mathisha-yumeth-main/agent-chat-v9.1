---
name: ssh-backup-remote
description: Create and verify backups on a server with tar or rsync.
---

# SSH Backup Remote

## When to use
Create and verify backups on a server with tar or rsync.

## Steps
1. Ask which paths matter and where backups go; check space with `df -h`
2. Create `tar -czf /backup/NAME-$(date +%F).tar.gz PATHS` (rsync only with approval)
3. Verify with `tar -tzf FILE | head` and compare sizes
4. Report the path, size and how to restore

## Output
Backup path, size, verification and restore command.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
