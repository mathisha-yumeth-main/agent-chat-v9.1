---
name: ssh-incident-triage
description: Calm step-by-step triage when something on a server is down.
---

# SSH Incident Triage

## When to use
Calm step-by-step triage when something on a server is down.

## Steps
1. Confirm the symptom with one check (`curl -I`, `systemctl status`, `ss -tulpn`)
2. Check in order: disk full, memory, failed services, recent changes (`last`, package logs)
3. Read the relevant logs and find the first error, not the loudest
4. Fix the smallest thing, verify, and write a 5-line incident note

## Output
Timeline, root cause, fix and prevention note.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
