---
name: ux-copy-reviewer
description: Improve button, error and empty-state text.
---

# UX Copy Reviewer

## When to use
Improve button, error and empty-state text.

## Steps
1. Collect the screens or strings and the user's situation
2. Rewrite to be short, specific and helpful: say what happened and what to do next
3. Keep a consistent tone and terms across the product

## Output
Before/after table of the text.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
