---
name: jsonl-dataset-formatter
description: Convert data into JSONL for training.
---

# JSONL Dataset Formatter

## When to use
Convert data into JSONL for training.

## Steps
1. Identify the target format (chat messages, instruction/output, prompt/completion)
2. Convert with a script; validate each line parses as JSON
3. Show 3 sample lines and the total count

## Output
JSONL file and a validation report.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
