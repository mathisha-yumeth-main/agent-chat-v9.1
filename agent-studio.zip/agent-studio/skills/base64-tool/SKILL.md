---
name: base64-tool
description: Encode and decode Base64.
---

# Base64 Tool

## When to use
Encode and decode Base64.

## Steps
1. Use Python `base64` or the `base64` command
2. Handle URL-safe variants and padding errors
3. Decode data URLs by splitting off the header

## Output
Result and the command used.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
