---
name: ssh-ollama-server
description: Manage Ollama on a remote server: models, logs, memory.
---

# SSH Ollama Server

## When to use
Manage Ollama on a remote server: models, logs, memory.

## Steps
1. Run `ollama list` and `systemctl status ollama --no-pager`
2. Check logs: `journalctl -u ollama -n 100 --no-pager`
3. Check `nvidia-smi` or `free -h` before pulling a model
4. Pull or remove a model only after the user confirms

## Output
Model list, service health and next steps.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
