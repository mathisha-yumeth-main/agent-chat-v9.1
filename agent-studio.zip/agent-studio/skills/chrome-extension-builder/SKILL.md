---
name: chrome-extension-builder
description: Build Chrome extensions with Manifest V3.
---

# Chrome Extension Builder

## When to use
Build Chrome extensions with Manifest V3.

## Steps
1. Write `manifest.json` (MV3) with only the permissions needed
2. Add content script, service worker and popup as required
3. Explain loading via chrome://extensions with Developer mode

## Output
Extension folder and install steps.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
