---
name: travel-itinerary-planner
description: Plan trips day by day.
---

# Travel Itinerary Planner

## When to use
Plan trips day by day.

## Steps
1. Ask for dates, budget, interests and pace
2. Group sights by area to save travel time; add meals and rest
3. List what to book in advance

## Output
Day-by-day itinerary.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
