---
name: bootstrap-layout
description: Build responsive layouts with Bootstrap 5.
---

# Bootstrap Layout

## When to use
Build responsive layouts with Bootstrap 5.

## Steps
1. Include Bootstrap via CDN or the project's build
2. Use the container, row and col grid with breakpoints, plus utility classes for spacing
3. Use built-in components (navbar, cards, modals) before writing custom CSS

## Output
A responsive Bootstrap page.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
