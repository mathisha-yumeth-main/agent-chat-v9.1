---
name: dataset-cleaner
description: Clean and deduplicate text datasets.
---

# Dataset Cleaner

## When to use
Clean and deduplicate text datasets.

## Steps
1. Load a sample and look for empty rows, encoding problems and duplicates
2. Normalize whitespace, drop exact and near duplicates, filter by length
3. Write the cleaned file and report counts before and after

## Output
Clean dataset and a change report.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
