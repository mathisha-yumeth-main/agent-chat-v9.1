---
name: windows-troubleshooter
description: Troubleshoot common Windows problems.
---

# Windows Troubleshooter

## When to use
Troubleshoot common Windows problems.

## Steps
1. Ask for the exact error and Windows version
2. Start with safe checks: `sfc /scannow`, `DISM /Online /Cleanup-Image /RestoreHealth`, Event Viewer, `ipconfig /all`
3. Explain each command before suggesting it and avoid registry edits unless needed

## Output
Ordered fix steps.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
