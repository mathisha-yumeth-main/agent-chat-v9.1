---
name: decision-matrix-builder
description: Compare options with a weighted matrix.
---

# Decision Matrix Builder

## When to use
Compare options with a weighted matrix.

## Steps
1. List options and criteria; ask the user for weights
2. Score each option 1-5 per criterion and compute weighted totals with a script
3. Run a quick sensitivity check on the weights

## Output
Matrix table and a recommendation.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
