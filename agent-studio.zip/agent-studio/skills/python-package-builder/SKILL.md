---
name: python-package-builder
description: Turn Python code into an installable package.
---

# Python Package Builder

## When to use
Turn Python code into an installable package.

## Steps
1. Create `pyproject.toml` (name, version, dependencies, entry points) and a `src/` layout
2. Add a README, license and tests
3. Build with `python -m build` and install into a clean venv to prove it works

## Output
Package that installs and imports.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
