---
name: interview-question-builder
description: Create structured interview questions.
---

# Interview Question Builder

## When to use
Create structured interview questions.

## Steps
1. Define the skills the role needs
2. Write behavioral and practical questions for each skill
3. Add what a good answer contains and a scoring scale

## Output
Question list with scoring guide.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
