---
name: csharp-developer
description: Write and debug C# and .NET projects.
---

# C# Developer

## When to use
Write and debug C# and .NET projects.

## Steps
1. Check `dotnet --version` and the project type with `dotnet new list` or the csproj
2. Use async/await, records and nullable reference types; keep classes small
3. Run `dotnet build` and `dotnet test` and fix warnings

## Output
Building C# code and the commands used.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
