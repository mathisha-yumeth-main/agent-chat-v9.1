---
name: r-language-helper
description: Write R scripts for data work and plots.
---

# R Language Helper

## When to use
Write R scripts for data work and plots.

## Steps
1. Read the data with `readr::read_csv` and check it with `str()` and `summary()`
2. Use tidyverse (`dplyr`, `ggplot2`) pipelines and keep steps readable
3. Run with `Rscript FILE.R` and save plots to files

## Output
R script that reproduces the analysis.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
