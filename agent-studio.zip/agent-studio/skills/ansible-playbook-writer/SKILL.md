---
name: ansible-playbook-writer
description: Write Ansible playbooks and roles.
---

# Ansible Playbook Writer

## When to use
Write Ansible playbooks and roles.

## Steps
1. Define inventory, hosts and desired state
2. Use modules (`apt`, `service`, `template`) rather than shell; make tasks idempotent
3. Run `ansible-playbook --check --diff` before a real run

## Output
Playbook plus a check-mode result.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
