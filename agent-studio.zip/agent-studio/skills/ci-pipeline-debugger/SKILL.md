---
name: ci-pipeline-debugger
description: Find why a CI pipeline fails.
---

# CI Pipeline Debugger

## When to use
Find why a CI pipeline fails.

## Steps
1. Read the failing job log from the first error upward
2. Separate environment problems (versions, missing secrets, cache) from real test failures
3. Reproduce locally with the same commands and propose the fix

## Output
Root cause and the exact change.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
