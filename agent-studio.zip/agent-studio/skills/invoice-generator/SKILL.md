---
name: invoice-generator
description: Create invoices as HTML or PDF.
---

# Invoice Generator

## When to use
Create invoices as HTML or PDF.

## Steps
1. Collect seller, client, items, quantities, rates, tax and payment terms
2. Calculate subtotal, tax and total with a script to avoid math errors
3. Write an HTML invoice and offer to convert to PDF

## Output
Invoice file and the totals.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
