---
name: url-encoder-decoder
description: Encode and decode URLs and query strings.
---

# URL Encoder Decoder

## When to use
Encode and decode URLs and query strings.

## Steps
1. Use `urllib.parse.quote` and `unquote`
2. Split and rebuild URLs with `urlparse` and `parse_qs`
3. Point out double-encoding problems

## Output
Decoded parts and a corrected URL.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
