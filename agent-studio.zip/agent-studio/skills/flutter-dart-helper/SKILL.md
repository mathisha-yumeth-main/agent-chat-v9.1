---
name: flutter-dart-helper
description: Write Dart and Flutter widgets and state management.
---

# Flutter Dart Helper

## When to use
Write Dart and Flutter widgets and state management.

## Steps
1. Ask for the target (mobile, web, desktop) and state approach
2. Build small `StatelessWidget`s, use `const`, keep logic out of `build`
3. Run `flutter analyze` and `flutter test`; flag that device builds need the Flutter SDK

## Output
Dart widget code with an explanation of state flow.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
