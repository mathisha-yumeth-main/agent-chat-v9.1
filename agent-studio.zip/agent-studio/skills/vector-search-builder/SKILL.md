---
name: vector-search-builder
description: Build semantic search with embeddings.
---

# Vector Search Builder

## When to use
Build semantic search with embeddings.

## Steps
1. Embed the texts and normalize the vectors
2. Search with cosine similarity (numpy for small sets, FAISS or SQLite extensions for bigger)
3. Return the top results with scores and test with paraphrased queries

## Output
Search script and example results.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
