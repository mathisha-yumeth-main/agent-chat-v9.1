---
name: mysql-query-tuner
description: Speed up slow MySQL queries.
---

# MySQL Query Tuner

## When to use
Speed up slow MySQL queries.

## Steps
1. Get the query and run `EXPLAIN` (or `EXPLAIN ANALYZE`)
2. Look for full scans, missing indexes and bad joins or sorts
3. Suggest an index or a rewrite and compare the plans before and after

## Output
Plan comparison and the exact change.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
