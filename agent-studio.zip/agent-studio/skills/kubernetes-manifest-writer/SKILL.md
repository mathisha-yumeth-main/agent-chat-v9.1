---
name: kubernetes-manifest-writer
description: Write Kubernetes Deployments, Services and Ingress.
---

# Kubernetes Manifest Writer

## When to use
Write Kubernetes Deployments, Services and Ingress.

## Steps
1. Gather image, ports, env, resources and replicas
2. Add liveness/readiness probes, resource requests and limits, and labels
3. Validate with `kubectl apply --dry-run=client -f FILE`

## Output
Valid YAML and the apply commands.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
