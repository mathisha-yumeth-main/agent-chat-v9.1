---
name: social-post-writer
description: Write social media posts for different platforms.
---

# Social Post Writer

## When to use
Write social media posts for different platforms.

## Steps
1. Ask for the goal, audience and platform
2. Write variants fitted to each platform's length and tone, with a hook in the first line
3. Suggest a call to action and hashtags sparingly

## Output
3 post variants per platform.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
