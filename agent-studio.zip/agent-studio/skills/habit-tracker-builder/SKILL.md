---
name: habit-tracker-builder
description: Build a habit tracker as an HTML page.
---

# Habit Tracker Builder

## When to use
Build a habit tracker as an HTML page.

## Steps
1. Ask for the habits and the period
2. Create a single HTML file with a grid and checkboxes
3. Keep data in memory only if browser storage is unavailable, and say so

## Output
One-file tracker.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
