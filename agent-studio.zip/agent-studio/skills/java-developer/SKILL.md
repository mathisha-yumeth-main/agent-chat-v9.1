---
name: java-developer
description: Write, build and test Java code with Maven or Gradle.
---

# Java Developer

## When to use
Write, build and test Java code with Maven or Gradle.

## Steps
1. Check `java -version` and whether the project uses Maven or Gradle
2. Follow existing package layout, use records and streams where they simplify the code
3. Run `mvn -q test` or `gradle test` and fix failures

## Output
Compiling Java code with passing tests.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
