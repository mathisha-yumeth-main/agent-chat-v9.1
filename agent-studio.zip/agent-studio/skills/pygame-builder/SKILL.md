---
name: pygame-builder
description: Build 2D games with Pygame.
---

# Pygame Builder

## When to use
Build 2D games with Pygame.

## Steps
1. Set up the loop: events, update, draw, fixed frame rate with `clock.tick(60)`
2. Use sprites or rects, delta time and simple collision checks
3. Keep assets optional (draw shapes) so it runs anywhere

## Output
A playable game file and controls list.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
