---
name: product-description-writer
description: Write product descriptions that sell honestly.
---

# Product Description Writer

## When to use
Write product descriptions that sell honestly.

## Steps
1. Collect features, who it is for and the main benefit
2. Lead with the benefit, then proof, then details in a short list
3. Avoid claims you cannot support

## Output
A short and a long description.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
