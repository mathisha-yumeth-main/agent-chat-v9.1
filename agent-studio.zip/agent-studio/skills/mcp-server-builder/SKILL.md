---
name: mcp-server-builder
description: Build a simple MCP server.
---

# MCP Server Builder

## When to use
Build a simple MCP server.

## Steps
1. Choose the transport (stdio) and the tools to expose
2. Implement `initialize`, `tools/list` and `tools/call` with JSON-RPC, or use an official SDK
3. Add it to the app's MCP settings and test one tool call

## Output
MCP server file and registration steps.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
