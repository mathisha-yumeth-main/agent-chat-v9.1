---
name: beautifulsoup-scraper
description: Extract data from HTML with requests and BeautifulSoup.
---

# BeautifulSoup Scraper

## When to use
Extract data from HTML with requests and BeautifulSoup.

## Steps
1. Check the site's robots.txt and terms; fetch with a clear User-Agent and a delay
2. Inspect the HTML and pick CSS selectors; handle missing elements
3. Save results to CSV or JSON and report how many rows were found

## Output
A polite scraper and the output file.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
