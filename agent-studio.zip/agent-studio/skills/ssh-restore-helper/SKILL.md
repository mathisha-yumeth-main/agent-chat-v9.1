---
name: ssh-restore-helper
description: Restore files from a backup on a server safely.
---

# SSH Restore Helper

## When to use
Restore files from a backup on a server safely.

## Steps
1. List contents with `tar -tzf FILE | grep NAME`
2. Restore into a temp folder first: `tar -xzf FILE -C /tmp/restore PATH`
3. Diff against the live files and show the differences
4. Copy over live files only after approval and keep a copy of what is replaced

## Output
Restore report: restored, replaced, kept.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
