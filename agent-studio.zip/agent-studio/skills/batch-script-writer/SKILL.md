---
name: batch-script-writer
description: Write Windows batch (.bat) scripts.
---

# Batch Script Writer

## When to use
Write Windows batch (.bat) scripts.

## Steps
1. Use `@echo off`, `setlocal` and quote paths with spaces
2. Use `%~dp0` for the script folder and check `%errorlevel%`
3. Prefer PowerShell for complex logic and say when

## Output
Batch file with comments.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
