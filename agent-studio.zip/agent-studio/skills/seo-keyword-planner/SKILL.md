---
name: seo-keyword-planner
description: Plan keywords and page topics for SEO.
---

# SEO Keyword Planner

## When to use
Plan keywords and page topics for SEO.

## Steps
1. Ask about the product, audience and country
2. List search intents (informational, comparison, buying) and group keywords by page
3. Suggest titles, headings and internal links; be honest that volumes need a real keyword tool

## Output
Keyword map by page.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
