---
name: date-time-calculator
description: Calculate dates, durations and weekdays.
---

# Date Time Calculator

## When to use
Calculate dates, durations and weekdays.

## Steps
1. Parse dates with Python's `datetime`
2. Compute differences, add business days and find weekdays
3. Always state the time zone used

## Output
Result with the calculation shown.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
