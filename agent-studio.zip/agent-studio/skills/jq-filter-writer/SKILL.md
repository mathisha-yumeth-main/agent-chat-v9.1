---
name: jq-filter-writer
description: Write jq filters.
---

# jq Filter Writer

## When to use
Write jq filters.

## Steps
1. Show the input shape with `jq 'keys'` or a sample
2. Build the filter step by step: select, map, group_by, sort_by
3. Test on the real file and print the result

## Output
jq command and result.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
