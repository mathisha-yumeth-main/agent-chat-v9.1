---
name: htmx-helper
description: Add interactivity with htmx and server-rendered HTML.
---

# htmx Helper

## When to use
Add interactivity with htmx and server-rendered HTML.

## Steps
1. Return HTML fragments from the server and use `hx-get`, `hx-post`, `hx-target` and `hx-swap`
2. Use `hx-trigger` for events and `hx-indicator` for loading states
3. Keep forms working without JavaScript where possible

## Output
Server routes and the htmx attributes that use them.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
