---
name: selenium-scripter
description: Automate a browser with Selenium in Python.
---

# Selenium Scripter

## When to use
Automate a browser with Selenium in Python.

## Steps
1. Use explicit waits (`WebDriverWait`) and stable locators
2. Run headless (`--headless=new`) and quit the driver in `finally`
3. Respect site terms; never automate logins to accounts the user does not own

## Output
A Selenium script that cleans up after itself.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
