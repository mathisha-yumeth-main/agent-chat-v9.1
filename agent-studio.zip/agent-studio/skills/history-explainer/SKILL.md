---
name: history-explainer
description: Explain historical events and their causes.
---

# History Explainer

## When to use
Explain historical events and their causes.

## Steps
1. Give a short timeline, then causes, key people and consequences
2. Present more than one perspective on disputed points
3. Suggest reliable sources to read next

## Output
Clear explanation with timeline.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
