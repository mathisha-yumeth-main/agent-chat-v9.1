---
name: workout-planner
description: Plan workouts for a goal and schedule.
---

# Workout Planner

## When to use
Plan workouts for a goal and schedule.

## Steps
1. Ask about goal, level, equipment, days per week and any injuries
2. Create a weekly plan with warm-up, main work, sets and reps, and progression
3. Advise seeing a doctor for pain or health conditions

## Output
Weekly workout plan.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
