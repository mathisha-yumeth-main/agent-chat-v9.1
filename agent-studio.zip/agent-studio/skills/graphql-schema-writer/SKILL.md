---
name: graphql-schema-writer
description: Design GraphQL schemas, queries and resolvers.
---

# GraphQL Schema Writer

## When to use
Design GraphQL schemas, queries and resolvers.

## Steps
1. List the entities and relations; define types, queries and mutations in SDL
2. Use input types, non-null where guaranteed, and pagination (cursor style)
3. Write sample queries and a resolver skeleton; avoid N+1 with batching

## Output
Schema file plus example queries.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
