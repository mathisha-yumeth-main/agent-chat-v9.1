---
name: cron-expression-explainer
description: Explain and write cron expressions.
---

# Cron Expression Explainer

## When to use
Explain and write cron expressions.

## Steps
1. Break the five fields down: minute, hour, day, month, weekday
2. Translate to plain words and list the next 5 run times with a script
3. Warn about time zone and day-of-month plus weekday behavior

## Output
Expression and next run times.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
