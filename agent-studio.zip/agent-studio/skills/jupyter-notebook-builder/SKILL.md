---
name: jupyter-notebook-builder
description: Create Jupyter notebooks.
---

# Jupyter Notebook Builder

## When to use
Create Jupyter notebooks.

## Steps
1. Plan sections: goal, data, steps, results
2. Write cells as small steps with markdown explanations
3. Create the .ipynb with the `nbformat` library and run it with `jupyter nbconvert --execute` when installed

## Output
A runnable notebook.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
