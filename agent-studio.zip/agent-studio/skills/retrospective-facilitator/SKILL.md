---
name: retrospective-facilitator
description: Run team retrospectives.
---

# Retrospective Facilitator

## When to use
Run team retrospectives.

## Steps
1. Choose a format (start/stop/continue, 4Ls, mad/sad/glad)
2. Collect points, group them, vote on the top 3
3. Turn them into actions with owners and dates

## Output
Retro notes and action list.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
