---
name: packing-list-maker
description: Create packing lists.
---

# Packing List Maker

## When to use
Create packing lists.

## Steps
1. Ask about destination, season, days and activities
2. Group items: documents, clothes, toiletries, electronics, extras
3. Add last-minute checks

## Output
Checklist.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
