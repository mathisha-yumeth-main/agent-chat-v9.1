---
name: awk-sed-helper
description: Write awk and sed one-liners.
---

# awk sed Helper

## When to use
Write awk and sed one-liners.

## Steps
1. Look at the lines to match and the output wanted
2. Write the command and explain every part
3. Test without `-i` first and use `-i.bak` for in-place changes

## Output
Command with explanation and sample output.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
