---
name: playwright-test-writer
description: Write end-to-end browser tests with Playwright.
---

# Playwright Test Writer

## When to use
Write end-to-end browser tests with Playwright.

## Steps
1. Identify user flows to cover and stable selectors (`getByRole`, `getByTestId`)
2. Write tests that wait on conditions, never on fixed sleeps
3. Run `npx playwright test` and attach failure details

## Output
Spec files with a short run guide.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
