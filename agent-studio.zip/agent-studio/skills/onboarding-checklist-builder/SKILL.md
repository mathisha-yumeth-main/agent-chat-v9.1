---
name: onboarding-checklist-builder
description: Build onboarding checklists.
---

# Onboarding Checklist Builder

## When to use
Build onboarding checklists.

## Steps
1. List what a new person needs by day 1, week 1 and month 1
2. Add owners and links
3. Include a check-in at the end of each period

## Output
Checklist by time period.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
