---
name: ollama-modelfile-writer
description: Write Ollama Modelfiles.
---

# Ollama Modelfile Writer

## When to use
Write Ollama Modelfiles.

## Steps
1. Choose the base with `FROM` and set `PARAMETER` values (temperature, num_ctx)
2. Add `SYSTEM` and `TEMPLATE` only when needed; use `ADAPTER` for LoRA files
3. Build with `ollama create NAME -f Modelfile` and test with `ollama run NAME`

## Output
Modelfile and the create/run commands.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
