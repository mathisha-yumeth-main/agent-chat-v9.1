---
name: ssh-docker-ops
description: Inspect and manage Docker containers on a server.
---

# SSH Docker Ops

## When to use
Inspect and manage Docker containers on a server.

## Steps
1. Run `docker ps -a --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"`
2. Read logs with `docker logs --tail 100 NAME`
3. Restart only the container the user named; never prune or rm without approval
4. Verify with `docker ps` and `docker inspect --format '{{.State.Status}}' NAME`

## Output
Container table, findings and actions taken.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
