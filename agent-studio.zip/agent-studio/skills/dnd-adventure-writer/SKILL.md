---
name: dnd-adventure-writer
description: Write tabletop RPG adventures.
---

# D&D Adventure Writer

## When to use
Write tabletop RPG adventures.

## Steps
1. Ask for level, group size, tone and length
2. Outline hook, 3-5 scenes, encounters, rewards and a twist
3. Add stat blocks or references in a system-neutral way

## Output
Adventure outline with encounters.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
