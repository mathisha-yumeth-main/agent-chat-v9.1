---
name: ssh-firewall-ufw
description: Review and plan ufw firewall rules on a server.
---

# SSH Firewall UFW

## When to use
Review and plan ufw firewall rules on a server.

## Steps
1. Read rules with `sudo ufw status numbered` (or `sudo iptables -S` if ufw is off)
2. Compare with what is really listening: `ss -tulpn`
3. Propose the smallest change and ALWAYS keep the SSH port allowed so the user is not locked out
4. Apply only after approval, then re-check status

## Output
Current vs proposed rules and the exact commands.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
