---
name: standup-summarizer
description: Summarize stand-up updates.
---

# Standup Summarizer

## When to use
Summarize stand-up updates.

## Steps
1. Collect the updates from the notes
2. Group by yesterday, today and blockers
3. Highlight blockers with owners

## Output
One-page summary.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
