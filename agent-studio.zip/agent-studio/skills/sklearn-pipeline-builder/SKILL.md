---
name: sklearn-pipeline-builder
description: Build scikit-learn pipelines.
---

# scikit-learn Pipeline Builder

## When to use
Build scikit-learn pipelines.

## Steps
1. Split data first; build a `Pipeline` with imputing, scaling/encoding and a model
2. Cross-validate and choose metrics that fit the problem
3. Report results, check for leakage and save the model with `joblib`

## Output
Training script and metrics.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
