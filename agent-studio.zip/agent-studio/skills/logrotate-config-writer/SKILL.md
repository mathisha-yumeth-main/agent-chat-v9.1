---
name: logrotate-config-writer
description: Write logrotate configs.
---

# Logrotate Config Writer

## When to use
Write logrotate configs.

## Steps
1. Find the log path and who writes it
2. Set `daily`, `rotate N`, `compress`, `missingok`, `notifempty` and a `postrotate` reload if needed
3. Test with `logrotate -d CONFIG` (debug, no changes)

## Output
A logrotate file and its dry-run result.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
