---
name: discord-bot-builder
description: Build a Discord bot with slash commands.
---

# Discord Bot Builder

## When to use
Build a Discord bot with slash commands.

## Steps
1. Use discord.py or discord.js with intents set to the minimum
2. Register slash commands and handle errors; keep the token in an env var
3. Explain bot setup in the developer portal; never print the token

## Output
Bot code and setup checklist.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
