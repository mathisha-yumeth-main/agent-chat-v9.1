---
name: password-policy-advisor
description: Advise on password rules and managers.
---

# Password Policy Advisor

## When to use
Advise on password rules and managers.

## Steps
1. Recommend long passphrases, unique passwords and a password manager
2. Suggest turning on two-factor authentication
3. Never ask for or store real passwords

## Output
Short policy and steps.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
