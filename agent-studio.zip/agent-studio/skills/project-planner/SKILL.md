---
name: project-planner
description: Break a project into milestones and tasks.
---

# Project Planner

## When to use
Break a project into milestones and tasks.

## Steps
1. Clarify the goal, deadline and people available
2. List milestones, split into tasks of 1-3 days, order by dependency
3. Mark the critical path and the riskiest items

## Output
Plan table with owners and dates.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
