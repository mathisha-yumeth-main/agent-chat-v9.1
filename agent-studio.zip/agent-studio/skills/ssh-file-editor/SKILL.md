---
name: ssh-file-editor
description: Edit a file on the server safely with a backup.
---

# SSH File Editor

## When to use
Edit a file on the server safely with a backup.

## Steps
1. Read it first: `cat -n PATH | head -200`
2. Back it up: `cp -a PATH PATH.bak-$(date +%F-%H%M)`
3. Change with a targeted `sed -i` or rewrite via `cat > PATH <<'EOF'`
4. Show `diff PATH.bak-* PATH` and run the right syntax check for the file type

## Output
Diff of the change and the backup file name.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
