---
name: press-release-writer
description: Write press releases.
---

# Press Release Writer

## When to use
Write press releases.

## Steps
1. Collect the news, quotes, date and contact
2. Write headline, lead paragraph with who/what/when/where/why, quotes and boilerplate
3. Keep it factual and under one page

## Output
Press release draft.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
