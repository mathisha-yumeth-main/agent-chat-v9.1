---
name: postgres-schema-designer
description: Design PostgreSQL tables, keys and indexes.
---

# PostgreSQL Schema Designer

## When to use
Design PostgreSQL tables, keys and indexes.

## Steps
1. List entities, relations and the main queries
2. Choose types, primary and foreign keys, constraints and indexes for the queries
3. Write DDL in a migration file and sample `EXPLAIN` checks

## Output
DDL script with reasoning for each index.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
