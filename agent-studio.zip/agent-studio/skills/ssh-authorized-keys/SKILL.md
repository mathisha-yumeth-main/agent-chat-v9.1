---
name: ssh-authorized-keys
description: Inspect and carefully manage SSH authorized_keys.
---

# SSH Authorized Keys

## When to use
Inspect and carefully manage SSH authorized_keys.

## Steps
1. List keys by fingerprint only: `ssh-keygen -lf ~/.ssh/authorized_keys`
2. Check permissions: ~/.ssh is 700 and authorized_keys is 600
3. Back up the file before adding or removing a key
4. Never remove a key unless the user confirms it is not the one in use

## Output
Key list with fingerprints and any permission fixes.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
