---
name: swift-helper
description: Write Swift and SwiftUI code and explain its patterns.
---

# Swift Helper

## When to use
Write Swift and SwiftUI code and explain its patterns.

## Steps
1. Ask whether it is a command-line tool, iOS or macOS app
2. Use value types, optionals and `async/await`; keep views small in SwiftUI
3. Note that building iOS apps needs Xcode on a Mac; give code and steps the user can run

## Output
Swift code plus where to run it.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
