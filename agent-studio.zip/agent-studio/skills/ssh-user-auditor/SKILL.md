---
name: ssh-user-auditor
description: Audit server users, sudo rights and recent logins.
---

# SSH User Auditor

## When to use
Audit server users, sudo rights and recent logins.

## Steps
1. List login users with `awk -F: '$3>=1000 || $3==0 {print $1,$3,$7}' /etc/passwd`
2. Check sudo with `getent group sudo wheel; ls /etc/sudoers.d`
3. Review `last -n 20` and `lastb -n 20 2>/dev/null`
4. Flag unknown users, empty passwords and shared accounts

## Output
User table with risks flagged.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
