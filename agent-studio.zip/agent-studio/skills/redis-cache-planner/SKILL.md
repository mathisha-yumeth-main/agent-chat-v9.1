---
name: redis-cache-planner
description: Plan caching with Redis.
---

# Redis Cache Planner

## When to use
Plan caching with Redis.

## Steps
1. Decide what to cache, key names, TTLs and invalidation rules
2. Pick structures (string, hash, set, sorted set) per use case
3. Plan eviction (`maxmemory-policy`) and avoid cache stampedes

## Output
Key design table and a code sample.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
