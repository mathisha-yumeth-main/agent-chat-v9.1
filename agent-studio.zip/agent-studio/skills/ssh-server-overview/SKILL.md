---
name: ssh-server-overview
description: Snapshot a remote server: OS, uptime, load, memory, disk.
---

# SSH Server Overview

## When to use
Snapshot a remote server: OS, uptime, load, memory, disk.

## Steps
1. Run `uname -a; cat /etc/os-release; uptime` in one ssh_run call
2. Run `free -h; df -hT -x tmpfs -x devtmpfs` for memory and disk
3. Run `systemctl --failed --no-pager; ss -tulpn | head -30` for failed units and open ports
4. Summarize health and list what needs attention

## Output
Short health report with numbers and a list of concerns.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
