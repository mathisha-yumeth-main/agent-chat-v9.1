---
name: ssh-python-deploy
description: Deploy a Python app on a server with a venv and systemd.
---

# SSH Python Deploy

## When to use
Deploy a Python app on a server with a venv and systemd.

## Steps
1. Check `python3 --version` and create `python3 -m venv .venv` in the app folder
2. Install with `.venv/bin/pip install -r requirements.txt`
3. Write a systemd unit that runs the app as a non-root user and enable it
4. Verify with `systemctl status` and a `curl` to the local port

## Output
Folder layout, unit file and verification output.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
