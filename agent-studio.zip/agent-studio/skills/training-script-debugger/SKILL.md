---
name: training-script-debugger
description: Debug failing model-training scripts.
---

# Training Script Debugger

## When to use
Debug failing model-training scripts.

## Steps
1. Read the traceback and find the first project-code frame
2. Check shapes, dtypes, device placement, batch size and memory
3. Test with a tiny batch to reproduce quickly, then fix and rerun

## Output
Cause and corrected code.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
