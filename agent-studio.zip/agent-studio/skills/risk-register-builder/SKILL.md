---
name: risk-register-builder
description: Build a project risk register.
---

# Risk Register Builder

## When to use
Build a project risk register.

## Steps
1. List risks with cause and effect
2. Rate likelihood and impact (1-5) and compute a score
3. Add mitigation, owner and a trigger for each risk above the threshold

## Output
Risk table sorted by score.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
