---
name: user-story-writer
description: Write user stories with acceptance criteria.
---

# User Story Writer

## When to use
Write user stories with acceptance criteria.

## Steps
1. Identify the user, the goal and the reason
2. Write "As a ..., I want ..., so that ..." plus 3-5 testable acceptance criteria
3. Split big stories into independent smaller ones

## Output
Backlog-ready stories.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
