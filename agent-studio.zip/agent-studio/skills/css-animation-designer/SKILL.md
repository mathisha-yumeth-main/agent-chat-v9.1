---
name: css-animation-designer
description: Design CSS animations and transitions.
---

# CSS Animation Designer

## When to use
Design CSS animations and transitions.

## Steps
1. Pick the purpose (feedback, attention, loading) and keep durations 150-400ms
2. Animate `transform` and `opacity` for smoothness; use `@keyframes` for loops
3. Respect `prefers-reduced-motion` and test the result

## Output
CSS snippet with a demo page.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
