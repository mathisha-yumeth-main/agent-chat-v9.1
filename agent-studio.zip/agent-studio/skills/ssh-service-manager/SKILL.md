---
name: ssh-service-manager
description: Inspect, restart and enable systemd services on a server.
---

# SSH Service Manager

## When to use
Inspect, restart and enable systemd services on a server.

## Steps
1. Check state with `systemctl status NAME --no-pager -l` and `systemctl is-enabled NAME`
2. Read the last logs with `journalctl -u NAME -n 50 --no-pager`
3. Restart or reload only after telling the user the impact; prefer `reload` when supported
4. Verify with status again and report the new state

## Output
Before/after state of the service.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
