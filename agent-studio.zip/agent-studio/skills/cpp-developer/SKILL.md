---
name: cpp-developer
description: Write modern C++ and fix compile and link errors.
---

# C++ Developer

## When to use
Write modern C++ and fix compile and link errors.

## Steps
1. Check the compiler (`g++ --version`) and the standard (use C++17 or newer)
2. Prefer RAII, `std::vector`, smart pointers; avoid raw `new`
3. Compile with `-Wall -Wextra` and run; explain errors line by line

## Output
Compiling C++ code with warnings fixed.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
