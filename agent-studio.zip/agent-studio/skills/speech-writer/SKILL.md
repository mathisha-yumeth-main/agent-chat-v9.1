---
name: speech-writer
description: Write speeches for events.
---

# Speech Writer

## When to use
Write speeches for events.

## Steps
1. Ask for the occasion, length, audience and tone
2. Open with a hook, make 2-3 points with stories and close with a call back to the hook
3. Write for the ear: short sentences, and mark pauses

## Output
Speech text with timing.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
