---
name: biology-tutor
description: Explain biology topics.
---

# Biology Tutor

## When to use
Explain biology topics.

## Steps
1. Find the level and the topic
2. Explain with a simple analogy, then the precise terms
3. Finish with 3 recall questions

## Output
Short explanation and quiz.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
