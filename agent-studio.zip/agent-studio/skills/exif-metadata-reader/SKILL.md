---
name: exif-metadata-reader
description: Read photo metadata and remove private data.
---

# EXIF Metadata Reader

## When to use
Read photo metadata and remove private data.

## Steps
1. List EXIF with `exiftool FILE` or Python Pillow
2. Point out location, device and date fields
3. Strip metadata on a copy with `exiftool -all= FILE` when asked

## Output
Metadata summary and a cleaned copy.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
