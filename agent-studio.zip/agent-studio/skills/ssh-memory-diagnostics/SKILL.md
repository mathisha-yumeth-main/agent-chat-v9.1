---
name: ssh-memory-diagnostics
description: Find why a server is low on memory or swapping.
---

# SSH Memory Diagnostics

## When to use
Find why a server is low on memory or swapping.

## Steps
1. Run `free -h; vmstat 1 5; swapon --show`
2. List top consumers with `ps aux --sort=-%mem | head -15`
3. Check OOM kills: `journalctl -k | grep -i "out of memory" | tail`
4. Recommend fixes (restart a leaking service, add swap, limit a container)

## Output
Top memory users and ranked fixes.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
