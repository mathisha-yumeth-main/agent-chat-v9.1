---
name: exam-prep-planner
description: Plan exam revision.
---

# Exam Prep Planner

## When to use
Plan exam revision.

## Steps
1. List topics, exam date and available hours
2. Build a schedule with spaced repetition and practice tests
3. Leave a buffer and rest days

## Output
Day-by-day study plan.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
