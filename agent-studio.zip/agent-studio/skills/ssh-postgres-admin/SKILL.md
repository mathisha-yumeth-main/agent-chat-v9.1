---
name: ssh-postgres-admin
description: Inspect a PostgreSQL server: sizes, connections, slow queries.
---

# SSH PostgreSQL Admin

## When to use
Inspect a PostgreSQL server: sizes, connections, slow queries.

## Steps
1. Run `sudo -u postgres psql -c "\l+"` for databases and sizes
2. Check `SELECT state, count(*) FROM pg_stat_activity GROUP BY 1;`
3. Find long queries where `now()-query_start > interval '1 min'`
4. Suggest indexes or settings; never DROP or DELETE without approval

## Output
Findings plus the read-only queries used.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
