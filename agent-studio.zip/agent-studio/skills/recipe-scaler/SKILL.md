---
name: recipe-scaler
description: Scale recipes up or down.
---

# Recipe Scaler

## When to use
Scale recipes up or down.

## Steps
1. Read the original servings and the target
2. Multiply amounts with a script; convert units sensibly
3. Adjust cooking time and pan size notes

## Output
Scaled ingredient list.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
