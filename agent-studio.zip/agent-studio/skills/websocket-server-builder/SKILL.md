---
name: websocket-server-builder
description: Build a WebSocket server and client.
---

# WebSocket Server Builder

## When to use
Build a WebSocket server and client.

## Steps
1. Define message formats (JSON with a `type` field)
2. Handle connect, message, broadcast and disconnect; add heartbeats
3. Test with two clients and show how to run both

## Output
Server and client code that talk to each other.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
