---
name: ssh-node-deploy
description: Deploy a Node.js app on a server with systemd or pm2.
---

# SSH Node Deploy

## When to use
Deploy a Node.js app on a server with systemd or pm2.

## Steps
1. Check `node -v; npm -v` and the package.json scripts
2. Install with `npm ci --omit=dev`; keep env vars in a file with mode 600
3. Run it with a systemd unit (or `pm2 start` if the user already uses pm2)
4. Verify the port with `ss -tulpn | grep PORT` and `curl`

## Output
Run command, unit file and health-check result.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
