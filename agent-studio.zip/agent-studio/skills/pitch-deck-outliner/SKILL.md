---
name: pitch-deck-outliner
description: Outline a pitch deck slide by slide.
---

# Pitch Deck Outliner

## When to use
Outline a pitch deck slide by slide.

## Steps
1. Ask for the audience and the ask
2. Outline: problem, solution, product, market, traction, model, team, ask
3. Write the one-sentence message for each slide

## Output
Slide list with key message per slide.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
