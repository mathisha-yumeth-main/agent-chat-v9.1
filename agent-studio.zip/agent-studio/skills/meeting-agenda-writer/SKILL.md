---
name: meeting-agenda-writer
description: Write meeting agendas.
---

# Meeting Agenda Writer

## When to use
Write meeting agendas.

## Steps
1. Ask for the goal, attendees and length
2. Time-box each item and mark decisions needed
3. Add pre-reading and the expected outcome

## Output
Agenda with timings.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
