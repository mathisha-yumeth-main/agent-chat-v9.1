---
name: telegram-bot-builder
description: Build a Telegram bot.
---

# Telegram Bot Builder

## When to use
Build a Telegram bot.

## Steps
1. Use python-telegram-bot or Telegraf; keep the token in an env var
2. Add command handlers, inline keyboards and error handling
3. Run with long polling for development and explain webhooks for production

## Output
Bot code plus how to get and use a token.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
