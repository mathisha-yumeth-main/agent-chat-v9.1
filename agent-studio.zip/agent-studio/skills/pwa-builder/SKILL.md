---
name: pwa-builder
description: Turn a website into an installable PWA.
---

# PWA Builder

## When to use
Turn a website into an installable PWA.

## Steps
1. Add `manifest.webmanifest` (name, icons, `display`, `start_url`)
2. Add a service worker with a cache-first strategy for static files
3. Serve over HTTPS or localhost and check install prompts

## Output
Manifest, service worker and registration code.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
