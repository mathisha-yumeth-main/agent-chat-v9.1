---
name: sop-writer
description: Write standard operating procedures.
---

# SOP Writer

## When to use
Write standard operating procedures.

## Steps
1. Observe or ask for the steps in order
2. Write numbered steps with who, what and what good looks like
3. Add checks, common mistakes and a revision date

## Output
SOP document.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
