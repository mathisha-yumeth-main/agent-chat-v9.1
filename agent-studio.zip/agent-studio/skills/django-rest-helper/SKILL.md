---
name: django-rest-helper
description: Build APIs with Django REST Framework.
---

# Django REST Helper

## When to use
Build APIs with Django REST Framework.

## Steps
1. Read `settings.py`, `urls.py` and models; create serializers and viewsets
2. Add permissions, pagination and filtering explicitly
3. Test with `APIClient` and run `python manage.py test`

## Output
Serializers, views, routes and tests.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
