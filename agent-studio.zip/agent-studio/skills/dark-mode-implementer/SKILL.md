---
name: dark-mode-implementer
description: Add dark mode to a site.
---

# Dark Mode Implementer

## When to use
Add dark mode to a site.

## Steps
1. Move colors into CSS variables on `:root`
2. Override them in `@media (prefers-color-scheme: dark)` and add a manual toggle with `data-theme`
3. Check contrast of text, borders and images in both themes

## Output
CSS variables, toggle code and a contrast check.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
