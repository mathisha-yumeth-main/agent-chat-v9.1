---
name: plotly-chart-maker
description: Make interactive charts with Plotly.
---

# Plotly Chart Maker

## When to use
Make interactive charts with Plotly.

## Steps
1. Choose the chart type from the question (line, bar, scatter, heatmap)
2. Build with `plotly.express`, label axes and titles
3. Save as a standalone HTML with `fig.write_html`

## Output
HTML chart file.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
