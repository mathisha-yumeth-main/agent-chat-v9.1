---
name: email-template-builder
description: Build HTML email templates that render everywhere.
---

# Email Template Builder

## When to use
Build HTML email templates that render everywhere.

## Steps
1. Use table layout, inline CSS and a max width of 600px
2. Add preheader text, alt text and a plain-text version
3. Test with different widths and a dark-mode check

## Output
HTML email and its text version.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
