---
name: ssh-tunnel-planner
description: Plan SSH port-forwarding commands for the user to run.
---

# SSH Tunnel Planner

## When to use
Plan SSH port-forwarding commands for the user to run.

## Steps
1. Ask what must be reached (remote port, database, web UI)
2. Write the exact `ssh -L LOCAL:HOST:REMOTE user@server` or `-R` command and explain each part
3. Warn about binding to 0.0.0.0 and exposing services
4. Say clearly that the agent cannot open tunnels: the user runs it in a terminal

## Output
One copy-ready command plus a plain explanation.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
