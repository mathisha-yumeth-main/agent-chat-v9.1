---
name: vscode-extension-builder
description: Build VS Code extensions.
---

# VS Code Extension Builder

## When to use
Build VS Code extensions.

## Steps
1. Scaffold with `yo code` (or write `package.json` and `extension.ts` by hand)
2. Register commands in `contributes` and `activate`
3. Run with F5 in the Extension Development Host

## Output
Minimal extension that adds one command.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
