---
name: character-sheet-builder
description: Create detailed characters for stories and games.
---

# Character Sheet Builder

## When to use
Create detailed characters for stories and games.

## Steps
1. Ask for the role in the story or game
2. Write goals, flaws, history, voice and relationships
3. Add a few dialogue lines in their voice

## Output
Character sheet.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
