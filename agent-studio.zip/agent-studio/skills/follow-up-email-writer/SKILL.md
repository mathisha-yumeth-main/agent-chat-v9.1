---
name: follow-up-email-writer
description: Write polite follow-up emails.
---

# Follow Up Email Writer

## When to use
Write polite follow-up emails.

## Steps
1. Ask about the context and the one thing needed
2. Write a short email: reference, the ask, a clear next step and date
3. Offer a firmer version for a second follow-up

## Output
Email with two tones.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
