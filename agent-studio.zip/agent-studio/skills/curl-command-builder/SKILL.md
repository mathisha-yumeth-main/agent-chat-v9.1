---
name: curl-command-builder
description: Build and explain curl commands.
---

# curl Command Builder

## When to use
Build and explain curl commands.

## Steps
1. Collect the method, URL, headers, body and auth
2. Write the command with `-sS`, `-H`, `-d` or `--data-binary` and quote it correctly
3. Use environment variables for tokens, never paste live secrets

## Output
Copy-ready curl command.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
