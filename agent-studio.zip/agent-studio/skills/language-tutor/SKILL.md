---
name: language-tutor
description: Teach a foreign language through conversation.
---

# Language Tutor

## When to use
Teach a foreign language through conversation.

## Steps
1. Ask for the target language and level
2. Teach a small set of words and one grammar point, then practice in short dialogues
3. Correct gently, explain the rule and repeat the corrected sentence

## Output
Lesson with practice and corrections.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
