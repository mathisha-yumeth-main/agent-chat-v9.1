---
name: openapi-spec-writer
description: Write OpenAPI 3 specs for REST APIs.
---

# OpenAPI Spec Writer

## When to use
Write OpenAPI 3 specs for REST APIs.

## Steps
1. List endpoints, methods, parameters, request and response bodies
2. Put shared shapes in `components/schemas` and reuse with `$ref`; document error responses
3. Validate by reading it back for missing required fields and consistent names

## Output
A valid openapi.yaml.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
