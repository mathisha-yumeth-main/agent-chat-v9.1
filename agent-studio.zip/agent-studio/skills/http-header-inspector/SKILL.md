---
name: http-header-inspector
description: Inspect and explain HTTP headers.
---

# HTTP Header Inspector

## When to use
Inspect and explain HTTP headers.

## Steps
1. Fetch headers with `curl -sSI URL` or Python `requests`
2. Explain status, cache, security (HSTS, CSP) and CORS headers
3. List missing security headers and recommend values

## Output
Header table with recommendations.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
