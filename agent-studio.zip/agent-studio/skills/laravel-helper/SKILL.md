---
name: laravel-helper
description: Build Laravel routes, models, migrations and controllers.
---

# Laravel Helper

## When to use
Build Laravel routes, models, migrations and controllers.

## Steps
1. Read `routes/web.php` and `composer.json` to learn the app's conventions
2. Use `php artisan make:*` commands, Eloquent relations and Form Requests for validation
3. Run `php artisan migrate` and `php artisan test` only after telling the user

## Output
Laravel files that follow the project's style.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
