---
name: nginx-config-writer
description: Write nginx configs for sites, proxies and TLS.
---

# nginx Config Writer

## When to use
Write nginx configs for sites, proxies and TLS.

## Steps
1. Decide the role: static site, reverse proxy, redirect or load balancer
2. Write the server block with correct `proxy_pass`, headers and gzip
3. Test with `nginx -t` when available and explain each directive

## Output
A config file with comments.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
