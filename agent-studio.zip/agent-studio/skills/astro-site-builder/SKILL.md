---
name: astro-site-builder
description: Build fast content sites with Astro.
---

# Astro Site Builder

## When to use
Build fast content sites with Astro.

## Steps
1. Start from `npm create astro@latest` conventions: `src/pages`, `src/components`, `src/layouts`
2. Use content collections for posts and ship zero JavaScript by default
3. Run `npm run build` and check the `dist` folder

## Output
A buildable Astro site with the commands to run it.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
