---
name: ssh-ssl-cert-checker
description: Check certificate expiry and Let's Encrypt renewal.
---

# SSH SSL Cert Checker

## When to use
Check certificate expiry and Let's Encrypt renewal.

## Steps
1. Check a live site: `echo | openssl s_client -connect HOST:443 -servername HOST 2>/dev/null | openssl x509 -noout -dates -subject`
2. List managed certs with `sudo certbot certificates`
3. Test renewal with `sudo certbot renew --dry-run`
4. Report days left and fix steps for any failure

## Output
Expiry table and renewal status.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
