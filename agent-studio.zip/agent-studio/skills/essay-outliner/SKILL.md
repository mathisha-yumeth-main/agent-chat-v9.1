---
name: essay-outliner
description: Outline essays and arguments.
---

# Essay Outliner

## When to use
Outline essays and arguments.

## Steps
1. Clarify the question and write a one-sentence thesis
2. Outline intro, 3 body points with evidence, counterargument and conclusion
3. Check that every point supports the thesis

## Output
Essay outline.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
