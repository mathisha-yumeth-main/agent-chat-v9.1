---
name: cli-tool-builder
description: Build a command-line tool with arguments and help text.
---

# CLI Tool Builder

## When to use
Build a command-line tool with arguments and help text.

## Steps
1. Define commands, flags and exit codes first
2. Use `argparse` (Python), `commander` (Node) or `clap` (Rust); give clear `--help`
3. Print errors to stderr and test with good and bad arguments

## Output
A CLI with usage examples.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
