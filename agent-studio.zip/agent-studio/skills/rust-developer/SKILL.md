---
name: rust-developer
description: Write and debug Rust with cargo, ownership and error handling.
---

# Rust Developer

## When to use
Write and debug Rust with cargo, ownership and error handling.

## Steps
1. Check `cargo --version`; create the crate with `cargo new`
2. Prefer `Result` with `?`, borrow before cloning, and explain borrow-checker errors in plain words
3. Run `cargo fmt`, `cargo clippy` and `cargo test`

## Output
Compiling Rust code and an explanation of any lifetime fix.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
