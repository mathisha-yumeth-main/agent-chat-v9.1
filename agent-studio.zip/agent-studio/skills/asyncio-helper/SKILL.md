---
name: asyncio-helper
description: Write and debug Python asyncio code.
---

# asyncio Helper

## When to use
Write and debug Python asyncio code.

## Steps
1. Identify what is I/O bound (network, files) vs CPU bound
2. Use `async def`, `asyncio.gather` with limits (`Semaphore`) and timeouts; never block the loop
3. Run it and check for un-awaited coroutines and cancelled tasks

## Output
Async code that runs, with the concurrency explained.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
