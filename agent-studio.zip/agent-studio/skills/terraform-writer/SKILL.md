---
name: terraform-writer
description: Write Terraform for cloud resources.
---

# Terraform Writer

## When to use
Write Terraform for cloud resources.

## Steps
1. Ask for the provider, region and what to create
2. Use variables, outputs and a remote state note; pin provider versions
3. Run `terraform fmt` and `terraform validate`; show `plan` output and never `apply` without approval

## Output
Terraform files and a plan summary.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
