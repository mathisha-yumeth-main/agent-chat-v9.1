---
name: ssh-process-killer
description: Stop a runaway process politely and verify.
---

# SSH Process Killer

## When to use
Stop a runaway process politely and verify.

## Steps
1. Find it with `ps aux | grep NAME`; confirm PID, owner and command with the user
2. Try `kill PID` first, wait 10 seconds, re-check
3. Use `kill -9` only if SIGTERM is ignored and the user approved
4. Verify it is gone and whether a service restarted it

## Output
What was stopped, how, and the result.

## Rules
- SSH must be ON (sidebar: MCP & SSH). Run every command on the server with `ssh_run`; local commands are disabled while SSH is on.
- Start with read-only commands and explain what you found before changing anything.
- Ask the user first before anything destructive or disruptive: deleting files, `kill -9`, firewall or sshd changes, restarting production services, package upgrades.
- Each `ssh_run` call is a fresh session that starts in the login folder: put `cd DIR && command` in one call.
- Never print passwords, keys or tokens. Verify the result after every change and report it honestly.
