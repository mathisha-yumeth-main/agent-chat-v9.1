---
name: storytelling-coach
description: Improve stories and presentations with narrative.
---

# Storytelling Coach

## When to use
Improve stories and presentations with narrative.

## Steps
1. Find the character, the problem and the change
2. Restructure: setup, conflict, turning point, resolution
3. Add concrete details and cut anything that slows it

## Output
Reworked outline or draft.

## Rules
- Use only tools the agent really has: read_file, write_file, edit_file, list_dir, glob, grep, run_command (or ssh_run when SSH is on), run_code, web_fetch.
- Read existing files before changing them, keep changes small, and create new files inside the workspace.
- If a needed program is not installed, say so plainly instead of pretending it ran.
- Ask before destructive changes, installs or anything outside the workspace. Never expose secrets.
