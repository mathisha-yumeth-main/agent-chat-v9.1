#!/usr/bin/env python3
"""Agent Studio backend. Standard library only.

Run:   python3 agent_server.py
Open:  http://127.0.0.1:8787

Env (optional):
  AGENT_WORKSPACE  folder the agent works in        (default: ./workspace)
  OLLAMA_URL       Ollama base URL                  (default: http://localhost:11434)
  DETECTOR_MODEL   danger-check model via Ollama    (default: d1-omni:600m)
  PORT             port                             (default: 8787)
"""
import atexit
import hashlib
import hmac
import secrets
import socket
import base64
import json
import os
import pathlib
import platform
import queue
import re
import shlex
import shutil
import sys
import tempfile
import threading
import subprocess
import time
import urllib.parse
import urllib.request
from urllib.parse import parse_qs, urlparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = pathlib.Path(__file__).resolve().parent
WORKSPACE = pathlib.Path(os.environ.get("AGENT_WORKSPACE", HERE / "workspace")).expanduser().resolve()
WORKSPACE.mkdir(parents=True, exist_ok=True)
PORT = int(os.environ.get("PORT", "8787"))
DEFAULT_OLLAMA = os.environ.get("OLLAMA_URL", "http://localhost:11434")
DEFAULT_DETECTOR = os.environ.get("DETECTOR_MODEL", "d1-omni:600m")
BUDGET = {"default": 0, "plan": 4000, "max": 16000}

# Always asks you first, no matter what the model says.
HARD_DANGER = [
    ("recursive or forced delete", r"\brm\b[^|;&]*\s-\w*[rRf]"),
    ("disk / format tool", r"\b(mkfs|fdisk|parted|format)\b"),
    ("raw disk write", r"\bdd\b.*\bof=/dev/|>\s*/dev/(sd|nvme|disk)"),
    ("privilege escalation", r"\b(sudo|su|doas)\b"),
    ("download piped to shell", r"(curl|wget)[^|]*\|\s*(sudo\s+)?(ba|z)?sh"),
    ("fork bomb", r":\(\)\s*\{"),
    ("shutdown / kill", r"\b(shutdown|reboot|halt|poweroff|killall|pkill)\b"),
    ("system directory", r"(^|\s)/(etc|bin|sbin|usr|boot|System|Library|dev|proc)\b"),
    ("recursive permission change", r"\b(chmod|chown)\b.*-R"),
    ("service / registry change", r"\b(reg\s+(add|delete)|systemctl|launchctl)\b"),
    ("destructive git", r"git\s+(reset\s+--hard|clean\s+-\w*f|push\s+.*--force)"),
    ("SQL drop / truncate", r"\b(drop\s+(table|database)|truncate\s+table)\b"),
    ("Windows delete", r"\b(del|erase|rmdir|rd)\b"),
    ("Windows system path", r"[A-Za-z]:\\(Windows|Program Files|ProgramData|Users)"),
    ("Windows system tool", r"\b(reg|sc|taskkill|diskpart|bcdedit|cipher|icacls|takeown|netsh|powershell|pwsh)\b"),
    ("download piped to PowerShell", r"(iwr|Invoke-WebRequest|curl|wget).*\|\s*(iex|Invoke-Expression)"),
]

DETECTOR_PROMPT = (
    "You are a strict shell-command safety classifier. Answer with one word only: DANGER or SAFE. "
    "DANGER = could delete, overwrite or corrupt data, change system or account settings, install or run "
    "downloaded code, touch files outside a project, expose secrets, or send data over the network. "
    "SAFE = read-only commands, builds, tests, listing, printing, or ordinary edits inside a project."
)


# ---------- HTTP helpers ----------
def unreachable(url, e):
    host = urllib.parse.urlparse(url).netloc or url
    hint = ""
    if "11434" in host:
        hint = " Start Ollama (open the Ollama app, or run 'ollama serve')."
    return f"cannot connect to {host} ({getattr(e, 'reason', e)}).{hint} Check the server address in Settings."

def post_json(url, body, headers=None, timeout=180):
    data = json.dumps(body).encode()
    h = {"Content-Type": "application/json"}
    h.update(headers or {})
    req = urllib.request.Request(url, data=data, headers=h, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.read().decode(errors='ignore')[:600]}")
    except urllib.error.URLError as e:
        raise RuntimeError(unreachable(url, e))


# ---------- Chat providers: each returns (text, thinking) ----------
# Models that rejected the "think" option stay on the plain path (no repeated failing requests).
NO_THINK = set()


def think_arg(model, effort):
    """Value for Ollama's "think" option, or None when thinking should not be requested at all.
    Works with every model: unsupported ones are detected once (HTTP 400) and remembered."""
    if effort == "default" or model in NO_THINK:
        return None
    if "gpt-oss" in model.lower():  # gpt-oss only understands levels, not booleans
        return "high" if effort == "max" else "medium"
    return True


def is_think_error(text):
    t = str(text).lower()
    return "think" in t and ("support" in t or "capab" in t or "400" in t)


def ollama_chat(base, model, messages, think=None, timeout=600, num_ctx=None):
    """think: None/False = off, True or "low"/"medium"/"high" = on. Retries without thinking if the
    model does not support it."""
    body = {"model": model, "messages": messages, "stream": False}
    if num_ctx:
        body["options"] = {"num_ctx": int(num_ctx)}
    if think:
        body["think"] = think
    try:
        d = post_json(base.rstrip("/") + "/api/chat", body, {}, timeout)
    except RuntimeError as e:
        if think and is_think_error(e):
            NO_THINK.add(model)
            body.pop("think")
            d = post_json(base.rstrip("/") + "/api/chat", body, {}, timeout)
        else:
            raise
    msg = d.get("message", {})
    content, thinking = msg.get("content", ""), msg.get("thinking", "")
    # Some models print <think>...</think> inside the answer instead of using the thinking field.
    m = re.match(r"\s*<think>([\s\S]*?)</think>\s*", content)
    if m:
        thinking = (thinking + "\n" + m.group(1)).strip()
        content = content[m.end():]
    usage = {"input": d.get("prompt_eval_count", 0), "output": d.get("eval_count", 0)}
    return content, thinking, usage


def chat_ollama(cfg, system, messages, effort):
    base = cfg.get("ollamaUrl") or DEFAULT_OLLAMA
    msgs = [{"role": "system", "content": system}] + messages
    return ollama_chat(base, cfg["model"], msgs, think=think_arg(cfg["model"], effort),
                       num_ctx=cfg.get("numCtx"))


def chat_claude(cfg, system, messages, effort):
    budget = BUDGET[effort]
    body = {"model": cfg["model"], "max_tokens": budget + 4096 if budget else 4096,
            "system": system, "messages": messages}
    if budget:
        body["thinking"] = {"type": "enabled", "budget_tokens": budget}
    d = post_json("https://api.anthropic.com/v1/messages", body,
                  {"x-api-key": cfg["keys"]["claude"], "anthropic-version": "2023-06-01"}, 600)
    text = "".join(b.get("text", "") for b in d["content"] if b["type"] == "text")
    thinking = "".join(b.get("thinking", "") for b in d["content"] if b["type"] == "thinking")
    u = d.get("usage", {})
    return text, thinking, {"input": u.get("input_tokens", 0), "output": u.get("output_tokens", 0)}


def chat_openai(cfg, system, messages, effort):
    body = {"model": cfg["model"], "messages": [{"role": "system", "content": system}] + messages}
    if re.match(r"^(o\d|gpt-5)", cfg["model"]) and effort != "default":
        body["reasoning_effort"] = {"plan": "medium", "max": "high"}[effort]
    d = post_json("https://api.openai.com/v1/chat/completions", body,
                  {"Authorization": "Bearer " + cfg["keys"]["chatgpt"]}, 600)
    u = d.get("usage", {})
    return d["choices"][0]["message"].get("content") or "", "", {
        "input": u.get("prompt_tokens", 0), "output": u.get("completion_tokens", 0)}


def chat_gemini(cfg, system, messages, effort):
    budget = BUDGET[effort]
    gc = {}
    if budget:
        gc["thinkingConfig"] = {"thinkingBudget": budget, "includeThoughts": True}
    body = {
        "systemInstruction": {"parts": [{"text": system}]},
        "contents": [{"role": "model" if m["role"] == "assistant" else "user",
                      "parts": [{"text": m["content"]}]} for m in messages],
        "generationConfig": gc,
    }
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/{cfg['model']}:generateContent"
           f"?key={cfg['keys']['gemini']}")
    d = post_json(url, body, {}, 600)
    parts = d["candidates"][0]["content"]["parts"]
    text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
    thinking = "".join(p.get("text", "") for p in parts if p.get("thought"))
    u = d.get("usageMetadata", {})
    return text, thinking, {"input": u.get("promptTokenCount", 0),
                            "output": u.get("candidatesTokenCount", 0),
                            "thinking": u.get("thoughtsTokenCount", 0)}


CHAT = {"ollama": chat_ollama, "claude": chat_claude, "chatgpt": chat_openai, "gemini": chat_gemini}


# ---------- Image providers: return (mime, base64) ----------
def aspect(size):
    return {"1536x1024": "4:3", "1024x1536": "3:4"}.get(size, "1:1")


def gen_image(cfg, prompt, size):
    p = cfg.get("imageProvider", "openai")
    model = cfg.get("imageModel") or ""
    if p == "openai":
        body = {"model": model or "gpt-image-1", "prompt": prompt, "size": size, "n": 1}
        if (model or "").startswith("dall-e"):
            body["response_format"] = "b64_json"
        d = post_json("https://api.openai.com/v1/images/generations", body,
                      {"Authorization": "Bearer " + cfg["keys"]["chatgpt"]}, 300)
        return "image/png", d["data"][0]["b64_json"]
    if p == "gemini":
        m = model or "imagen-4.0-generate-001"
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{m}:predict?key={cfg['keys']['gemini']}"
        d = post_json(url, {"instances": [{"prompt": prompt}],
                            "parameters": {"sampleCount": 1, "aspectRatio": aspect(size)}}, {}, 300)
        pr = d["predictions"][0]
        return pr.get("mimeType", "image/png"), pr["bytesBase64Encoded"]
    if p == "custom":
        if not cfg.get("customUrl"):
            raise RuntimeError("Set the custom image endpoint in Settings first.")
        h = {"Authorization": "Bearer " + cfg["keys"]["custom"]} if cfg["keys"].get("custom") else {}
        d = post_json(cfg["customUrl"], {"model": model, "prompt": prompt, "n": 1, "size": size,
                                         "response_format": "b64_json"}, h, 300)
        item = d["data"][0]
        if item.get("b64_json"):
            return "image/png", item["b64_json"]
        try:
            with urllib.request.urlopen(item["url"], timeout=120) as r:
                return r.headers.get_content_type(), base64.b64encode(r.read()).decode()
        except urllib.error.URLError as e:
            raise RuntimeError(unreachable(item["url"], e))
    raise RuntimeError(f"unknown image provider: {p}")


# ---------- Safety ----------
# Built-in fallback used only when the Ollama safety detector cannot answer. Every chained part of the
# command must be a plain read/build/edit-in-workspace command with no absolute paths, no home paths,
# no parent-folder paths and no command substitution. Anything else still asks for approval.
SAFE_WORDS = {"ls", "pwd", "echo", "cat", "head", "tail", "wc", "grep", "rg", "find", "sort", "uniq", "diff",
              "date", "whoami", "tree", "file", "stat", "du", "which", "make", "mkdir", "touch", "cp",
              "git", "npm", "npx", "pytest", "node", "python", "python3", "sed", "jq"}
SAFE_SCRIPT = re.compile(r"^(python3?|node)\s+[\w./-]+\.(py|js)(\s+[\w./=-]+)*$")
def heuristic_safe(cmd):
    if re.search(r"`|\$\(|\$\{|\.\./|(^|\s)[/~]|\bsudo\b|\brm\b|\bmv\b|\bchmod\b|\bchown\b", cmd):
        return False
    if re.search(r"\bfind\b.*-(delete|exec)|\bsed\b.*\s-i|\bgit\s+(push|reset|clean|checkout\s+--)", cmd):
        return False
    parts = [p.strip() for p in re.split(r"&&|\|\||;|\|", cmd) if p.strip()]
    if not parts:
        return False
    for p in parts:
        first = p.split()[0]
        if first in ("python", "python3", "node"):
            if not SAFE_SCRIPT.match(p):
                return False
        elif first not in SAFE_WORDS or first in ("npm", "npx", "git") and not re.match(r"^(npm|npx|git)\s+(test|run|status|diff|log|add|commit|branch|show|ls|list|help|--version|-v)\b|^(npm|npx|git)\s*$", p):
            return False
    return True


def classify(cmd, detector, ollama):
    hits = [label for label, rx in HARD_DANGER if re.search(rx, cmd, re.I)]
    try:
        out, _, _ = ollama_chat(ollama, detector,
                             [{"role": "system", "content": DETECTOR_PROMPT},
                              {"role": "user", "content": cmd}], think=False, timeout=60)
        up = out.upper()
        verdict = "DANGER" if "DANGER" in up else ("SAFE" if "SAFE" in up else "UNCLEAR")
    except Exception:
        verdict = "UNAVAILABLE"  # detector down: use the built-in allowlist, otherwise fail closed
        if not hits and heuristic_safe(cmd):
            verdict = "SAFE"
    return bool(hits) or verdict != "SAFE", verdict, hits


# ---------- Tools ----------
def resolve(p):
    t = pathlib.Path(os.path.expanduser(p))
    return (t if t.is_absolute() else WORKSPACE / t).resolve()


def inside(t):
    try:
        t.relative_to(WORKSPACE)
        return True
    except ValueError:
        return False


def run_tool(name, a, cfg, approved):
    if name == "run_command":
        if SSH_CONN["on"]:
            return {"ok": False, "error": "Local commands are turned off while SSH is on. Use ssh_run to run "
                                           "commands on the SSH server (or ask the user to turn SSH off)."}
        cmd = str(a.get("command", "")).strip()
        if not cmd:
            return {"ok": False, "error": "empty command"}
        danger, verdict, hits = classify(cmd, cfg.get("detector") or DEFAULT_DETECTOR,
                                         cfg.get("ollamaUrl") or DEFAULT_OLLAMA)
        if danger and not approved:
            return {"needs_approval": True, "verdict": verdict,
                    "reasons": hits or [f"detector: {verdict.lower()}"]}
        try:
            p = subprocess.run(cmd, shell=True, cwd=WORKSPACE, capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=180)
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "timed out after 180s"}
        return {"ok": True, "exit_code": p.returncode,
                "stdout": p.stdout[-8000:], "stderr": p.stderr[-4000:]}

    if name in ("read_file", "write_file", "edit_file", "list_dir"):
        t = resolve(str(a.get("path", ".")))
        if not inside(t) and not approved:
            return {"needs_approval": True, "verdict": "OUTSIDE",
                    "reasons": [f"{name} outside the workspace: {t}"]}
        if name == "read_file":
            if not t.is_file():
                return {"ok": False, "error": f"not a file: {t}"}
            data = t.read_text(encoding="utf-8", errors="replace")
            return {"ok": True, "path": str(t), "content": data[:20000], "truncated": len(data) > 20000}
        if name == "list_dir":
            if not t.is_dir():
                return {"ok": False, "error": f"not a folder: {t}"}
            names = sorted(x.name + ("/" if x.is_dir() else "") for x in t.iterdir())
            return {"ok": True, "path": str(t), "entries": names[:500]}
        if name == "write_file":
            t.parent.mkdir(parents=True, exist_ok=True)
            t.write_text(str(a.get("content", "")), encoding="utf-8")
            return {"ok": True, "path": str(t), "bytes": t.stat().st_size}
        if name == "edit_file":
            if not t.is_file():
                return {"ok": False, "error": "file not found"}
            src = t.read_text(encoding="utf-8", errors="replace")
            old = str(a.get("old", ""))
            n = src.count(old) if old else 0
            if n != 1:
                return {"ok": False, "error": f"'old' must match exactly once (found {n})"}
            t.write_text(src.replace(old, str(a.get("new", "")), 1), encoding="utf-8")
            return {"ok": True, "path": str(t), "message": "edited"}

    if name == "generate_image":
        prompt = str(a.get("prompt", "")).strip()
        if not prompt:
            return {"ok": False, "error": "empty prompt"}
        size = a.get("size") or cfg.get("size") or "1024x1024"
        mime, b64 = gen_image(cfg, prompt, size)
        ext = "jpg" if "jpeg" in mime else "png"
        out = WORKSPACE / "images" / f"img_{int(time.time())}.{ext}"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(base64.b64decode(b64))
        return {"ok": True, "path": str(out.relative_to(WORKSPACE)),
                "data_url": f"data:{mime};base64,{b64}"}

    if name == "ssh_run":
        hname = str(a.get("host", "")).strip()
        cmd = str(a.get("command", "")).strip()
        if not SSH_CONN["on"]:
            return {"ok": False, "error": "SSH is off. Ask the user to turn SSH on (sidebar: MCP & SSH)."}
        if hname.lower() in ("", "connected", "current", "session", "ssh"):
            if not cmd:
                return {"ok": False, "error": "empty command"}
            danger, verdict, hits = classify(cmd, cfg.get("detector") or DEFAULT_DETECTOR,
                                             cfg.get("ollamaUrl") or DEFAULT_OLLAMA)
            if danger and not approved:
                return {"needs_approval": True, "verdict": verdict,
                        "reasons": hits or [f"detector: {verdict.lower()}"],
                        "action": f"run on SSH ({SSH_CONN['label']}): {cmd}"}
            return ssh_session_run(cmd)
        h = next((x for x in load_cfg()["ssh_hosts"] if x["name"] == hname), None)
        if not h:
            known = ", ".join(x["name"] for x in load_cfg()["ssh_hosts"]) or "none"
            return {"ok": False, "error": f"unknown SSH host '{hname}'. Configured hosts: {known}"}
        if not cmd:
            return {"ok": False, "error": "empty command"}
        danger, verdict, hits = classify(cmd, cfg.get("detector") or DEFAULT_DETECTOR,
                                         cfg.get("ollamaUrl") or DEFAULT_OLLAMA)
        reasons = list(hits)
        if verdict != "SAFE":
            reasons.append("detector: " + verdict.lower())
        if not h.get("trusted"):
            reasons.append("host is not marked trusted")
        if reasons and not approved:
            return {"needs_approval": True, "verdict": verdict, "reasons": reasons,
                    "action": f"run on SSH host {hname}: {cmd}"}
        try:
            p = subprocess.run(ssh_argv(h, cmd), capture_output=True, text=True,
                               encoding="utf-8", errors="replace", timeout=180)
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "SSH command timed out after 180s"}
        except FileNotFoundError:
            return {"ok": False, "error": "ssh client not found. Install OpenSSH (Windows: Settings > Optional features > OpenSSH Client)."}
        return {"ok": True, "exit_code": p.returncode, "stdout": p.stdout[-8000:], "stderr": p.stderr[-4000:]}

    if name.startswith("mcp."):
        parts = name.split(".", 2)
        if len(parts) != 3:
            return {"ok": False, "error": "bad MCP tool name"}
        _, sname, tname = parts
        if not mcp_trusted(sname) and not approved:
            return {"needs_approval": True, "verdict": "MCP", "reasons": ["MCP server is not marked trusted"],
                    "action": f"call MCP tool {tname} on server {sname} with {json.dumps(a)[:300]}"}
        return call_mcp_tool(sname, tname, a)

    if name == "glob":
        return tool_glob(str(a.get("pattern", "")), str(a.get("path", ".")))
    if name == "grep":
        return tool_grep(str(a.get("pattern", "")), str(a.get("path", ".")), str(a.get("glob", "**/*")))
    if name == "web_fetch":
        if not approved:
            return {"needs_approval": True, "verdict": "WEB", "reasons": ["downloads a web page"],
                    "action": f"fetch {a.get('url', '')}"}
        return tool_web_fetch(str(a.get("url", "")))
    if name == "todo_write":
        todos = a.get("todos", [])
        return {"ok": True, "count": len(todos), "todos": todos}
    if name == "load_skill":
        return load_skill(str(a.get("name", "")))
    if name == "run_code":
        code = str(a.get("code", ""))
        if not code.strip():
            return {"ok": False, "error": "empty code"}
        return tool_run_code(code, approved)

    return {"ok": False, "error": f"unknown tool: {name}"}


# ---------- Model discovery ----------
def http_get(url, headers=None, timeout=20):
    req = urllib.request.Request(url, headers=headers or {}, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}: {e.read().decode(errors='ignore')[:300]}")
    except urllib.error.URLError as e:
        raise RuntimeError(unreachable(url, e))


NOT_CHAT = re.compile(r"embed|whisper|tts|dall-e|moderation|davinci|babbage|transcribe|image|audio|realtime|search", re.I)


def openai_ids(key):
    d = http_get("https://api.openai.com/v1/models", {"Authorization": "Bearer " + key})
    return [m["id"] for m in d.get("data", [])]


def list_models(kind, provider, cfg):
    """Ask the provider which models this key or server can use. Returns {models, error}."""
    keys = cfg.get("keys") or {}

    def need(name):
        if not keys.get(name):
            raise RuntimeError("add an API key first (Settings)")
        return keys[name]

    try:
        if kind == "chat" and provider == "ollama":
            base = (cfg.get("ollamaUrl") or DEFAULT_OLLAMA).rstrip("/")
            names = [m["name"] for m in http_get(base + "/api/tags").get("models", [])]
        elif kind == "chat" and provider == "claude":
            d = http_get("https://api.anthropic.com/v1/models?limit=200",
                         {"x-api-key": need("claude"), "anthropic-version": "2023-06-01"})
            names = [m["id"] for m in d.get("data", [])]
        elif kind == "chat" and provider == "chatgpt":
            names = [i for i in openai_ids(need("chatgpt"))
                     if re.match(r"^(gpt-|o\d|chatgpt)", i) and not NOT_CHAT.search(i)]
        elif kind == "image" and provider == "openai":
            names = [i for i in openai_ids(need("chatgpt")) if re.search(r"image|dall-e", i)]
        elif provider == "gemini":
            d = http_get(f"https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000&key={need('gemini')}")
            names = []
            for m in d.get("models", []):
                n = m["name"].split("/", 1)[-1]
                methods = m.get("supportedGenerationMethods", [])
                if kind == "chat" and "generateContent" in methods and "image" not in n and "tts" not in n:
                    names.append(n)
                if kind == "image" and "predict" in methods:
                    names.append(n)
        elif kind == "image" and provider == "custom":
            base = re.sub(r"/images/generations/?$", "", (cfg.get("customUrl") or "").rstrip("/"))
            if not base:
                raise RuntimeError("set the custom image endpoint first")
            h = {"Authorization": "Bearer " + keys["custom"]} if keys.get("custom") else {}
            names = [m["id"] for m in http_get(base + "/models", h).get("data", [])]
        else:
            raise RuntimeError(f"not supported: {kind} / {provider}")
        return {"models": sorted(set(names)), "error": None}
    except Exception as e:
        return {"models": [], "error": str(e)}


def host_info():
    os_name = platform.system()
    if os_name == "Windows":
        hint = ("Windows. Commands run in cmd.exe. Use Windows commands such as dir, type, copy, move, "
                "mkdir and findstr. PowerShell is available through 'powershell -Command'. "
                "Paths may use backslashes or forward slashes.")
    elif os_name == "Darwin":
        hint = "macOS. Commands run in /bin/sh. Use POSIX shell commands."
    else:
        hint = "Linux. Commands run in /bin/sh with standard GNU tools."
    return {"os": os_name, "hint": hint, "workspace": str(WORKSPACE), "version": 5}


# ---------- MCP servers and SSH ----------
MCP_FILE = HERE / "mcp_config.json"
MCP_CLIENTS = {}
MCP_LOCK = threading.Lock()


def clean_name(n):
    return re.sub(r"[^A-Za-z0-9_-]", "_", str(n).strip())[:40]


def load_cfg():
    try:
        d = json.loads(MCP_FILE.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        d = {}
    return {"servers": d.get("servers", []), "ssh_hosts": d.get("ssh_hosts", [])}


def save_cfg(cfg):
    servers = []
    for s_ in cfg.get("servers", []):
        if s_.get("name") and s_.get("command"):
            servers.append({"name": clean_name(s_["name"]), "command": str(s_["command"]).strip(),
                            "args": [str(x) for x in s_.get("args", []) if str(x).strip()],
                            "enabled": bool(s_.get("enabled", True)), "trusted": bool(s_.get("trusted", False))})
    hosts = []
    for h in cfg.get("ssh_hosts", []):
        if h.get("name") and h.get("host"):
            hosts.append({"name": clean_name(h["name"]), "host": str(h["host"]).strip(),
                          "user": str(h.get("user", "")).strip(), "port": int(h.get("port") or 22),
                          "key": str(h.get("key", "")).strip(), "trusted": bool(h.get("trusted", False))})
    clean = {"servers": servers, "ssh_hosts": hosts}
    MCP_FILE.write_text(json.dumps(clean, indent=2), encoding="utf-8")
    mcp_stop_all()
    return clean


class MCPClient:
    """Minimal MCP client over stdio (JSON-RPC, one message per line)."""

    def __init__(self, srv):
        self.srv = srv
        self.proc = None
        self.q = queue.Queue()
        self.nid = 0
        self.lock = threading.Lock()
        self.tools = []

    def start(self):
        self.proc = subprocess.Popen([self.srv["command"], *self.srv.get("args", [])],
                                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     cwd=str(WORKSPACE), text=True, encoding="utf-8", bufsize=1)
        threading.Thread(target=self._read, daemon=True).start()
        self.call("initialize", {"protocolVersion": "2024-11-05", "capabilities": {},
                                 "clientInfo": {"name": "agent-studio", "version": "1.0"}}, 30)
        self.notify("notifications/initialized")
        self.tools = self.call("tools/list", {}, 30).get("tools", [])

    def _read(self):
        try:
            for line in self.proc.stdout:
                line = line.strip()
                if line:
                    try:
                        self.q.put(json.loads(line))
                    except json.JSONDecodeError:
                        pass
        finally:
            self.q.put(None)

    def _write(self, obj):
        self.proc.stdin.write(json.dumps(obj) + "\n")
        self.proc.stdin.flush()

    def notify(self, method, params=None):
        msg = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            msg["params"] = params
        self._write(msg)

    def call(self, method, params, timeout=120):
        with self.lock:
            self.nid += 1
            rid = self.nid
            self._write({"jsonrpc": "2.0", "id": rid, "method": method, "params": params})
            end = time.time() + timeout
            while True:
                left = end - time.time()
                if left <= 0:
                    raise RuntimeError(f"MCP {method} timed out")
                try:
                    msg = self.q.get(timeout=left)
                except queue.Empty:
                    raise RuntimeError(f"MCP {method} timed out")
                if msg is None:
                    raise RuntimeError("MCP server exited")
                if msg.get("id") == rid:
                    if "error" in msg:
                        raise RuntimeError(str(msg["error"].get("message", "MCP error")))
                    return msg.get("result", {})

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def stop(self):
        try:
            self.proc.terminate()
        except Exception:
            pass


def mcp_client(name):
    with MCP_LOCK:
        c = MCP_CLIENTS.get(name)
        if c and c.alive():
            return c
        srv = next((x for x in load_cfg()["servers"] if x["name"] == name and x.get("enabled", True)), None)
        if not srv:
            raise RuntimeError(f"no enabled MCP server named {name}")
        c = MCPClient(srv)
        c.start()
        MCP_CLIENTS[name] = c
        return c


def mcp_stop_all():
    with MCP_LOCK:
        for c in MCP_CLIENTS.values():
            c.stop()
        MCP_CLIENTS.clear()


def mcp_trusted(sname):
    return any(x["name"] == sname and x.get("trusted") for x in load_cfg()["servers"])


def list_tools():
    cfg = load_cfg()
    tools, status = [], {}
    for srv in cfg["servers"]:
        if not srv.get("enabled", True):
            continue
        try:
            c = mcp_client(srv["name"])
            status[srv["name"]] = {"ok": True, "count": len(c.tools)}
            for t in c.tools:
                tools.append({"name": f"mcp.{srv['name']}.{t['name']}", "description": t.get("description", ""),
                              "schema": t.get("inputSchema", {}), "server": srv["name"]})
        except Exception as e:
            status[srv["name"]] = {"ok": False, "error": str(e)}
    return {"tools": tools, "status": status, "ssh_hosts": [h["name"] for h in cfg["ssh_hosts"]],
            "ssh": ssh_status()}


def call_mcp_tool(sname, tname, args):
    c = mcp_client(sname)
    res = c.call("tools/call", {"name": tname, "arguments": args}, 180)
    text = "\n".join(x.get("text", "") for x in res.get("content", []) if x.get("type") == "text")
    return {"ok": not res.get("isError", False), "output": (text or json.dumps(res))[:15000]}


def ssh_argv(h, command):
    target = f"{h['user']}@{h['host']}" if h.get("user") else h["host"]
    argv = ["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10",
            "-o", "StrictHostKeyChecking=accept-new", "-p", str(h.get("port", 22))]
    if h.get("key"):
        argv += ["-i", os.path.expanduser(h["key"])]
    return argv + [target, command]


# ---------- SSH session: paste the same ssh command you use in a terminal, plus the password ----------
SSH_CONN = {"on": False, "opts": [], "dest": "", "label": "", "password": ""}
SSH_LOCK = threading.Lock()
SSH_VALUE_FLAGS = set("BbcDEeFIiJLlmOopQRSWwP")   # ssh options that take a value
SSH_DROP_FLAGS = {"-N", "-f", "-t", "-tt", "-ttt", "-T", "-n"}   # make no sense for running one command
SSH_MARK = "AGENT_STUDIO_SSH_OK"


def parse_ssh_command(text):
    """Split a pasted `ssh -p 22 user@host` into (options, destination). No shell is ever involved."""
    text = str(text or "").strip()
    if text[:2] in ("$ ", "> "):
        text = text[2:].strip()
    if not text:
        raise RuntimeError("Paste your ssh command first, for example: ssh user@192.168.1.10")
    try:
        parts = shlex.split(text, posix=(os.name != "nt"))
    except ValueError as e:
        raise RuntimeError(f"Could not read that command ({e}).")
    parts = [x[1:-1] if len(x) >= 2 and x[0] == x[-1] and x[0] in "\"'" else x for x in parts]
    if not parts or os.path.basename(parts[0]).lower() not in ("ssh", "ssh.exe"):
        raise RuntimeError("The command must start with ssh, for example: ssh user@192.168.1.10")
    args, opts, dest, i = parts[1:], [], None, 0
    while i < len(args):
        a = args[i]
        if a.startswith("-") and len(a) > 1:      # options may come before or after the host: ssh host -p 22
            if a in SSH_DROP_FLAGS:
                i += 1
                continue
            opts.append(a)
            if not a.startswith("--"):
                body = a[1:]
                for k, ch in enumerate(body):
                    if ch in SSH_VALUE_FLAGS:
                        if k == len(body) - 1:          # value is the next word, e.g.  -p 2222
                            i += 1
                            if i >= len(args):
                                raise RuntimeError(f"The option {a} needs a value after it.")
                            opts.append(args[i])
                        break                          # otherwise the value is attached, e.g.  -p2222
        elif dest is None:
            dest = a
        else:
            raise RuntimeError("Paste only the connection command (for example: ssh user@host), "
                               "without a command after it.")
        i += 1
    if not dest:
        raise RuntimeError("No host found. Use the form: ssh user@host")
    return opts, dest


_ASKPASS = {}


def askpass_path():
    """A tiny helper that ssh calls when it asks for the password; it prints it from an env variable."""
    if "path" in _ASKPASS and os.path.isfile(_ASKPASS["path"]):
        return _ASKPASS["path"]
    d = pathlib.Path(tempfile.gettempdir()) / "agent-studio-askpass"
    d.mkdir(parents=True, exist_ok=True)
    (d / "askpass.py").write_text(
        "import os, sys\nsys.stdout.write(os.environ.get('AGENT_STUDIO_SSH_PW', '') + '\\n')\n", encoding="utf-8")
    if os.name == "nt":
        def short(pth):   # avoid spaces in paths: ssh starts the helper without quoting
            try:
                import ctypes
                buf = ctypes.create_unicode_buffer(1024)
                n = ctypes.windll.kernel32.GetShortPathNameW(str(pth), buf, 1024)
                return buf.value if n else str(pth)
            except Exception:
                return str(pth)
        f = d / "askpass.bat"
        f.write_text(f'@echo off\r\n"{short(sys.executable)}" "{short(d / "askpass.py")}"\r\n', encoding="utf-8")
        _ASKPASS["path"] = short(f)
    else:
        f = d / "askpass.sh"
        f.write_text(f'#!/bin/sh\nexec "{sys.executable}" "{d / "askpass.py"}" "$@"\n', encoding="utf-8")
        f.chmod(0o700)
        _ASKPASS["path"] = str(f)
    return _ASKPASS["path"]


def ssh_conn_argv(command):
    c = SSH_CONN
    return (["ssh"] + c["opts"] +
            ["-o", "ConnectTimeout=15", "-o", "StrictHostKeyChecking=accept-new",
             "-o", "NumberOfPasswordPrompts=1", "-o", "ServerAliveInterval=15", c["dest"], command])


def ssh_hint(err):
    e = (err or "").lower()
    if "permission denied" in e or "authentication failed" in e:
        return "Wrong password or user, or the server does not allow password login."
    if "connection refused" in e:
        return "The server refused the connection. Is the SSH server running, and is the port right?"
    if "timed out" in e or "no route to host" in e or "network is unreachable" in e:
        return "Could not reach the server. Check the address, your network, and any firewall."
    if "could not resolve" in e or "name or service not known" in e:
        return "The host name could not be found. Check the spelling of the host."
    if "host identification has changed" in e:
        return "The server's host key changed. If that is expected, remove the old key with: ssh-keygen -R <host>"
    return ""


def ssh_session_run(command, timeout=180):
    c = SSH_CONN
    env = dict(os.environ)
    env.update({"SSH_ASKPASS": askpass_path(), "SSH_ASKPASS_REQUIRE": "force",
                "DISPLAY": env.get("DISPLAY") or "agent-studio:0", "AGENT_STUDIO_SSH_PW": c["password"]})
    kw = dict(capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout,
              stdin=subprocess.DEVNULL, env=env)
    if os.name == "nt":
        kw["creationflags"] = 0x08000000      # no console window; ssh must use the helper, not the console
    else:
        kw["start_new_session"] = True        # no controlling terminal; ssh must use the helper
    try:
        p = subprocess.run(ssh_conn_argv(command), **kw)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"SSH command timed out after {timeout}s"}
    except FileNotFoundError:
        return {"ok": False, "error": "ssh client not found. Install OpenSSH (Windows: Settings > Optional features > OpenSSH Client)."}
    out, err = p.stdout, p.stderr
    if len(c["password"]) >= 3:
        out, err = out.replace(c["password"], "***"), err.replace(c["password"], "***")
    res = {"ok": True, "exit_code": p.returncode, "stdout": out[-8000:], "stderr": err[-4000:]}
    if p.returncode == 255:      # ssh itself failed (not the remote command)
        res["ok"] = False
        res["error"] = (err.strip().splitlines() or ["ssh connection failed"])[-1]
        hint = ssh_hint(err)
        if hint:
            res["hint"] = hint
    return res


def ssh_status():
    return {"on": bool(SSH_CONN["on"]), "label": SSH_CONN["label"]}


def ssh_connect(command, password):
    opts, dest = parse_ssh_command(command)
    with SSH_LOCK:
        SSH_CONN.update({"on": False, "opts": opts, "dest": dest, "label": dest, "password": str(password or "")})
        r = ssh_session_run(f"echo {SSH_MARK}", timeout=45)
        if r.get("ok") and SSH_MARK in r.get("stdout", ""):
            SSH_CONN["on"] = True
            return {"ok": True, "label": dest}
        SSH_CONN["password"] = ""
        lines = (r.get("stderr") or "").strip().splitlines()
        err = r.get("error") or (lines[-1] if lines else "could not connect")
        return {"ok": False, "error": err, "hint": r.get("hint", "") or ssh_hint(r.get("stderr", ""))}


def ssh_disconnect():
    with SSH_LOCK:
        SSH_CONN.update({"on": False, "opts": [], "dest": "", "label": "", "password": ""})
    return {"ok": True}


# ---------- Files, skills and code running ----------
SKILLS_DIR = HERE / "skills"
IMG_EXT = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp")
MIME = {".txt": "text/plain; charset=utf-8", ".md": "text/markdown; charset=utf-8", ".py": "text/plain; charset=utf-8",
        ".json": "application/json", ".csv": "text/csv; charset=utf-8", ".html": "text/html; charset=utf-8",
        ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif",
        ".webp": "image/webp", ".bmp": "image/bmp"}


def ws_path(rel):
    rel = str(rel or ".")
    t = (pathlib.Path(rel) if os.path.isabs(rel) else WORKSPACE / rel).resolve()
    if t != WORKSPACE and WORKSPACE not in t.parents:
        raise RuntimeError("that file is outside the workspace")
    return t


def hidden_parts(parts):
    return any(p.startswith(".") for p in parts)


def list_files(rel="."):
    root = ws_path(rel)
    entries = []
    for f in sorted(root.rglob("*")):
        parts = f.relative_to(WORKSPACE).parts
        if hidden_parts(parts):
            continue
        entries.append({"path": f.relative_to(WORKSPACE).as_posix(), "dir": f.is_dir(),
                        "size": 0 if f.is_dir() else f.stat().st_size})
        if len(entries) >= 500:
            break
    return {"entries": entries}


def file_info(rel):
    t = ws_path(rel)
    if not t.is_file():
        raise RuntimeError("not a file")
    size, ext = t.stat().st_size, t.suffix.lower()
    if ext in IMG_EXT:
        return {"kind": "image", "name": t.name, "size": size, "ext": ext}
    data = t.read_bytes()[:2_000_000]
    if b"\x00" in data[:4096]:
        return {"kind": "binary", "name": t.name, "size": size, "ext": ext}
    return {"kind": "text", "name": t.name, "size": size, "ext": ext,
            "content": data.decode("utf-8", errors="replace")}


def safe_pattern(p):
    p = str(p or "")
    if not p or os.path.isabs(p) or ".." in pathlib.PurePath(p).parts:
        raise RuntimeError("the pattern must stay inside the workspace (no '..' or absolute paths)")
    return p


def inside_ws(f):
    try:
        f.resolve().relative_to(WORKSPACE)
        return True
    except ValueError:
        return False


def tool_glob(pattern, path="."):
    root = ws_path(path)
    pattern = safe_pattern(pattern)
    hits = []
    for f in root.glob(pattern):
        if not inside_ws(f):
            continue
        rel = f.relative_to(WORKSPACE)
        if f.is_file() and not hidden_parts(rel.parts):
            hits.append(rel.as_posix())
        if len(hits) >= 300:
            break
    return {"ok": True, "matches": sorted(hits)}


def tool_grep(pattern, path=".", glob_pat="**/*"):
    root = ws_path(path)
    rx = re.compile(pattern)
    glob_pat = safe_pattern(glob_pat or "**/*")
    out, scanned = [], 0
    for f in root.glob(glob_pat):
        if not inside_ws(f):
            continue
        rel = f.relative_to(WORKSPACE)
        if not f.is_file() or f.stat().st_size > 1_000_000 or hidden_parts(rel.parts):
            continue
        scanned += 1
        try:
            lines = f.read_text(encoding="utf-8").splitlines()
        except (UnicodeDecodeError, OSError):
            continue
        for n, line in enumerate(lines, 1):
            if rx.search(line):
                out.append(f"{rel.as_posix()}:{n}: {line[:200]}")
            if len(out) >= 200:
                break
        if len(out) >= 200 or scanned >= 5000:
            break
    return {"ok": True, "matches": out}


def tool_web_fetch(url):
    if not re.match(r"^https?://", url):
        raise RuntimeError("only http and https addresses are allowed")
    req = urllib.request.Request(url, headers={"User-Agent": "AgentStudio/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            raw = r.read(300_000)
            ctype = r.headers.get_content_type()
    except urllib.error.URLError as e:
        raise RuntimeError(unreachable(url, e))
    text = raw.decode("utf-8", errors="replace")
    if ctype == "text/html":
        text = re.sub(r"(?is)<(script|style).*?</\1>", " ", text)
        text = re.sub(r"(?s)<[^>]+>", " ", text)
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n\s*\n+", "\n\n", text)
    return {"ok": True, "url": url, "content": text[:20000]}


def tool_run_code(code, approved):
    if not approved:
        return {"needs_approval": True, "verdict": "CODE", "reasons": ["runs Python code on this computer"],
                "action": f"run Python code ({len(code)} characters)"}
    runs = WORKSPACE / ".runs"
    runs.mkdir(exist_ok=True)
    f = runs / f"run_{int(time.time() * 1000)}.py"
    f.write_text(code, encoding="utf-8")
    try:
        p = subprocess.run([sys.executable, str(f)], cwd=WORKSPACE, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=60)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "Python run timed out after 60 seconds"}
    return {"ok": True, "exit_code": p.returncode, "stdout": p.stdout[-8000:],
            "stderr": p.stderr[-4000:], "file": f.relative_to(WORKSPACE).as_posix()}


def parse_skill(text):
    m = re.match(r"^---\n(.*?)\n---\n?(.*)$", text, re.S)
    if not m:
        return {}, text
    meta = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            meta[k.strip()] = v.strip()
    return meta, m.group(2)


def list_skills():
    SKILLS_DIR.mkdir(exist_ok=True)
    out = []
    for d in sorted(SKILLS_DIR.iterdir()):
        f = d / "SKILL.md"
        if d.is_dir() and f.is_file():
            meta, _ = parse_skill(f.read_text(encoding="utf-8", errors="replace"))
            out.append({"name": meta.get("name", d.name), "description": meta.get("description", ""), "dir": d.name})
    return out


def save_skill(name, description, body):
    safe = clean_name(name)
    if not safe or not str(description).strip():
        raise RuntimeError("a skill needs a name and a description")
    d = SKILLS_DIR / safe
    d.mkdir(parents=True, exist_ok=True)
    desc = " ".join(str(description).split())
    (d / "SKILL.md").write_text(f"---\nname: {safe}\ndescription: {desc}\n---\n\n{str(body).strip()}\n", encoding="utf-8")
    return {"ok": True, "name": safe}


def delete_skill(name):
    d = SKILLS_DIR / clean_name(name)
    if d.is_dir() and SKILLS_DIR in d.parents:
        shutil.rmtree(d)
    return {"ok": True}


def load_skill(name):
    f = SKILLS_DIR / clean_name(name) / "SKILL.md"
    if not f.is_file():
        raise RuntimeError(f"no skill named {name}")
    _, body = parse_skill(f.read_text(encoding="utf-8", errors="replace"))
    return {"ok": True, "name": name, "content": body.strip()[:30000]}


def stream_ollama(handler, body):
    """Relay Ollama's streamed answer line by line. If the browser stops, the upstream request is closed,
    which makes Ollama stop generating. Works with any model: thinking is requested only when supported."""
    cfg = body["cfg"]
    model = cfg["model"]
    base = (cfg.get("ollamaUrl") or DEFAULT_OLLAMA).rstrip("/")
    req_body = {"model": model, "stream": True,
                "messages": [{"role": "system", "content": body["system"]}] + body["messages"]}
    if cfg.get("numCtx"):
        req_body["options"] = {"num_ctx": int(cfg["numCtx"])}
    think = think_arg(model, body.get("effort", "default"))
    if think:
        req_body["think"] = think

    def open_req():
        req = urllib.request.Request(base + "/api/chat", data=json.dumps(req_body).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
        return urllib.request.urlopen(req, timeout=600)

    try:
        try:
            upstream = open_req()
        except urllib.error.HTTPError as e:
            msg = e.read().decode(errors="ignore")[:300]
            if think and is_think_error(msg):  # model has no thinking support: retry as a normal chat
                NO_THINK.add(model)
                req_body.pop("think", None)
                upstream = open_req()
            else:
                return handler.json_out(500, {"error": f"HTTP {e.code}: {msg}"})
    except urllib.error.HTTPError as e:
        return handler.json_out(500, {"error": f"HTTP {e.code}: {e.read().decode(errors='ignore')[:300]}"})
    except urllib.error.URLError as e:
        return handler.json_out(500, {"error": unreachable(base, e)})
    handler.send_response(200)
    handler.send_header("Content-Type", "application/x-ndjson")
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    try:
        with upstream:
            for line in upstream:
                if line.strip():
                    handler.wfile.write(line if line.endswith(b"\n") else line + b"\n")
                    handler.wfile.flush()
    except (BrokenPipeError, ConnectionResetError):
        return  # the browser stopped; leaving the with-block closes Ollama's request
    except Exception as e:
        try:
            handler.wfile.write((json.dumps({"error": str(e)}) + "\n").encode())
        except OSError:
            pass


# ---------- Accounts, sign-in and per-user chat storage ----------
DATA = HERE / "data"
USERS_FILE = DATA / "users.json"
CHATS_DIR = DATA / "chats"
ACCT_LOCK = threading.Lock()
LOG_LOCK = threading.Lock()
SESSIONS = {}            # token -> {"uid", "t"}; kept in memory, so a restart signs everyone out
SESSION_HOURS = 12


def tlog(who, msg):
    """One line per event in the terminal, so everything done on the web is visible here."""
    with LOG_LOCK:
        print(f"{time.strftime('%H:%M:%S')} [{who}] {msg}", flush=True)


def load_users():
    try:
        return json.loads(USERS_FILE.read_text(encoding="utf-8")).get("users", [])
    except (OSError, ValueError):
        return []


def save_users(users):
    DATA.mkdir(parents=True, exist_ok=True)
    tmp = USERS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps({"users": users}, indent=2), encoding="utf-8")
    os.replace(tmp, USERS_FILE)


def pw_hash(pw, salt_hex):
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), bytes.fromhex(salt_hex), 200_000).hex()


def public_user(u):
    return {"id": u["id"], "name": u["name"], "role": u["role"], "created": u.get("created", 0)}


def check_name_pw(name, pw):
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", name or ""):
        raise ValueError("Username: 3 to 32 letters, digits, dot, dash or underscore")
    if not pw or len(pw) < 8:
        raise ValueError("Password: at least 8 characters")
    if len(pw) > 200:
        raise ValueError("Password is too long")


def create_user(name, pw, role):
    name = (name or "").strip()
    check_name_pw(name, pw)
    with ACCT_LOCK:
        users = load_users()
        if any(u["name"].lower() == name.lower() for u in users):
            raise ValueError("That username is already taken")
        salt = secrets.token_hex(16)
        u = {"id": secrets.token_hex(8), "name": name, "role": role, "salt": salt,
             "hash": pw_hash(pw, salt), "created": time.time()}
        users.append(u)
        save_users(users)
    return u


def set_password(uid, pw, keep_token=None):
    if not pw or len(pw) < 8:
        raise ValueError("Password: at least 8 characters")
    with ACCT_LOCK:
        users = load_users()
        u = next((x for x in users if x["id"] == uid), None)
        if not u:
            raise ValueError("No such user")
        u["salt"] = secrets.token_hex(16)
        u["hash"] = pw_hash(pw, u["salt"])
        save_users(users)
        for t in [t for t, s in SESSIONS.items() if s["uid"] == uid and t != keep_token]:
            SESSIONS.pop(t, None)


def delete_user(uid, by_uid):
    if uid == by_uid:
        raise ValueError("You cannot delete the account you are using")
    with ACCT_LOCK:
        users = load_users()
        target = next((x for x in users if x["id"] == uid), None)
        if not target:
            raise ValueError("No such user")
        if target["role"] == "admin" and sum(1 for x in users if x["role"] == "admin") <= 1:
            raise ValueError("Cannot delete the last admin")
        save_users([x for x in users if x["id"] != uid])
        for t in [t for t, s in SESSIONS.items() if s["uid"] == uid]:
            SESSIONS.pop(t, None)
    try:
        chats_path(uid).unlink()
    except OSError:
        pass


def login_user(name, pw):
    users = load_users()
    u = next((x for x in users if x["name"].lower() == (name or "").strip().lower()), None)
    if u is None:
        pw_hash(pw or "", "00" * 16)          # same amount of work for unknown names
        return None
    return u if hmac.compare_digest(pw_hash(pw or "", u["salt"]), u["hash"]) else None


def new_session(uid):
    tok = secrets.token_urlsafe(32)
    SESSIONS[tok] = {"uid": uid, "t": time.time()}
    return tok


def current_user(handler):
    handler.token = None
    m = re.search(r"(?:^|;\s*)as_sess=([A-Za-z0-9_-]+)", handler.headers.get("Cookie", ""))
    if not m:
        return None
    s = SESSIONS.get(m.group(1))
    if not s:
        return None
    if time.time() - s["t"] > SESSION_HOURS * 3600:
        SESSIONS.pop(m.group(1), None)
        return None
    s["t"] = time.time()
    handler.token = m.group(1)
    return next((u for u in load_users() if u["id"] == s["uid"]), None)


def chats_path(uid):
    if not re.fullmatch(r"[0-9a-f]{16}", uid or ""):
        raise ValueError("bad user id")
    return CHATS_DIR / f"{uid}.json"


def read_chats(uid):
    try:
        return json.loads(chats_path(uid).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def write_chats(uid, chats):
    CHATS_DIR.mkdir(parents=True, exist_ok=True)
    p = chats_path(uid)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(chats, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, p)              # atomic: a crash never leaves half a file


def lan_addresses():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))   # no packet is sent; it only picks the outgoing interface
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(ip for ip in ips if not ip.startswith("127."))


PUBLIC_PATHS = {"/", "/index.html", "/api/auth/state", "/api/auth/login", "/api/auth/setup"}
QUIET_PREFIXES = ("/api/auth/state", "/api/info", "/api/files", "/api/file", "/api/image", "/api/raw", "/api/log")


# ---------- HTTP ----------
class Handler(BaseHTTPRequestHandler):
    server_version = "AgentStudio/1.0"
    user = None
    token = None
    extra_headers = ()

    def log_message(self, fmt, *args):
        pass

    def send_body(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in self.extra_headers:
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def signin(self, u):
        tok = new_session(u["id"])
        self.extra_headers = [("Set-Cookie", f"as_sess={tok}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_HOURS * 3600}")]
        self.json_out(200, {"user": public_user(u)})

    def gate(self, method):
        """Login check for every /api route, admin check for admin routes, terminal log for each call."""
        path = urlparse(self.path).path
        self.user = current_user(self)
        self.extra_headers = ()
        if path in PUBLIC_PATHS or not path.startswith("/api/"):
            return True
        if self.user is None:
            if method == "POST":
                self.rfile.read(int(self.headers.get("Content-Length", 0) or 0))
            self.json_out(401, {"error": "Please sign in."})
            return False
        if (path.startswith("/api/admin/") or path == "/api/config") and self.user["role"] != "admin":
            self.json_out(403, {"error": "Only the admin can do this."})
            return False
        if not path.startswith(QUIET_PREFIXES):
            tlog(self.user["name"], f"{method} {path} from {self.client_address[0]}")
        return True

    def json_out(self, code, obj):
        self.send_body(code, json.dumps(obj).encode(), "application/json")

    def do_GET(self):
        if not self.gate("GET"):
            return
        try:
            self._get()
        except Exception as e:
            self.json_out(500, {"error": str(e)})

    def _get(self):
        if self.path in ("/", "/index.html"):
            self.send_body(200, (HERE / "index.html").read_bytes(), "text/html; charset=utf-8")
        elif self.path.startswith("/api/image?"):
            rel = parse_qs(urlparse(self.path).query).get("path", [""])[0]
            target = (WORKSPACE / rel).resolve()
            if (WORKSPACE / "images").resolve() in target.parents and target.is_file():
                ctype = "image/jpeg" if target.suffix.lower() in (".jpg", ".jpeg") else "image/png"
                self.send_body(200, target.read_bytes(), ctype)
            else:
                self.json_out(404, {"error": "image not found"})
        elif self.path.startswith("/api/files"):
            self.json_out(200, list_files(parse_qs(urlparse(self.path).query).get("dir", ["."])[0]))
        elif self.path.startswith("/api/file?"):
            self.json_out(200, file_info(parse_qs(urlparse(self.path).query).get("path", [""])[0]))
        elif self.path.startswith("/api/raw?"):
            t = ws_path(parse_qs(urlparse(self.path).query).get("path", [""])[0])
            if not t.is_file():
                raise RuntimeError("file not found")
            inline = t.suffix.lower() in IMG_EXT  # only images open inline; everything else downloads
            body = t.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", MIME.get(t.suffix.lower(), "application/octet-stream") if inline
                             else "application/octet-stream")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            if not inline:
                self.send_header("Content-Disposition", f'attachment; filename="{t.name}"')
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/api/skills":
            self.json_out(200, list_skills())
        elif self.path == "/api/info":
            self.json_out(200, host_info())
        elif self.path == "/api/config":
            self.json_out(200, load_cfg())
        elif self.path == "/api/tools":
            self.json_out(200, list_tools())
        elif self.path == "/api/auth/state":
            self.json_out(200, {"setup": not load_users(), "user": public_user(self.user) if self.user else None})
        elif self.path == "/api/chats":
            self.json_out(200, {"chats": read_chats(self.user["id"])})
        elif self.path == "/api/admin/users":
            self.json_out(200, {"users": [dict(public_user(u), chats=len(read_chats(u["id"]))) for u in load_users()]})
        elif self.path.startswith("/api/admin/chats"):
            uid = parse_qs(urlparse(self.path).query).get("uid", [""])[0]
            target = next((u for u in load_users() if u["id"] == uid), None)
            if not target:
                raise ValueError("No such user")
            self.json_out(200, {"user": public_user(target), "chats": read_chats(uid)})
        elif self.path == "/api/ssh/status":
            self.json_out(200, ssh_status())
        else:
            self.json_out(404, {"error": "not found"})

    def do_POST(self):
        if not self.gate("POST"):
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
            body = json.loads(self.rfile.read(length) or b"{}")
            if self.path == "/api/chat":
                fn = CHAT[body["provider"]]
                text, thinking, usage = fn(body["cfg"], body["system"], body["messages"], body.get("effort", "default"))
                return self.json_out(200, {"text": text, "thinking": thinking, "usage": usage})
            if self.path == "/api/tool":
                try:
                    res = run_tool(body["name"], body.get("args", {}), body["cfg"], bool(body.get("approved")))
                except Exception as e:
                    res = {"ok": False, "error": str(e)}
                what = body.get("args", {}) or {}
                detail = str(what.get("command") or what.get("path") or what.get("pattern") or what.get("url") or "")[:160]
                state = ("ok" if res.get("ok") else "needs approval" if res.get("needs_approval")
                         else "error: " + str(res.get("error", ""))[:120])
                tlog(self.user["name"], f"tool {body.get('name')} {detail} -> {state}")
                return self.json_out(200, res)
            if self.path == "/api/chat-stream":
                cfg_ = body.get("cfg") or {}
                tlog(self.user["name"], f"chat -> {body.get('provider')} model={cfg_.get('model')} "
                                        f"effort={body.get('effort')} messages={len(body.get('messages') or [])}")
                return stream_ollama(self, body)
            if self.path == "/api/auth/setup":
                if load_users():
                    return self.json_out(409, {"error": "An admin account already exists. Sign in instead."})
                u = create_user(body.get("name", ""), body.get("password", ""), "admin")
                tlog("auth", f"admin account '{u['name']}' created from {self.client_address[0]}")
                return self.signin(u)
            if self.path == "/api/auth/login":
                u = login_user(body.get("name", ""), body.get("password", ""))
                if u is None:
                    time.sleep(0.6)
                    tlog("auth", f"FAILED sign-in for '{body.get('name', '')}' from {self.client_address[0]}")
                    return self.json_out(401, {"error": "Wrong username or password."})
                tlog("auth", f"'{u['name']}' ({u['role']}) signed in from {self.client_address[0]}")
                return self.signin(u)
            if self.path == "/api/auth/logout":
                SESSIONS.pop(self.token, None)
                tlog("auth", f"'{self.user['name']}' signed out")
                self.extra_headers = [("Set-Cookie", "as_sess=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0")]
                return self.json_out(200, {"ok": True})
            if self.path == "/api/auth/password":
                if not login_user(self.user["name"], body.get("old", "")):
                    return self.json_out(403, {"error": "The current password is wrong."})
                set_password(self.user["id"], body.get("new", ""), keep_token=self.token)
                tlog("auth", f"'{self.user['name']}' changed their password")
                return self.json_out(200, {"ok": True})
            if self.path == "/api/chats":
                chats = body.get("chats", [])
                if not isinstance(chats, list):
                    raise ValueError("chats must be a list")
                write_chats(self.user["id"], chats)
                tlog(self.user["name"], f"chats saved: {len(chats)} chat(s)")
                return self.json_out(200, {"ok": True, "count": len(chats)})
            if self.path == "/api/log":
                tlog(f"web {self.user['name']}", f"{str(body.get('kind', ''))}: {str(body.get('text', ''))[:400]}")
                return self.json_out(200, {"ok": True})
            if self.path == "/api/admin/users":
                role = "admin" if body.get("role") == "admin" else "user"
                u = create_user(body.get("name", ""), body.get("password", ""), role)
                tlog("admin", f"{self.user['name']} created account '{u['name']}' ({role})")
                return self.json_out(200, {"user": public_user(u)})
            if self.path == "/api/admin/users/delete":
                delete_user(body.get("id", ""), self.user["id"])
                tlog("admin", f"{self.user['name']} deleted account {body.get('id', '')}")
                return self.json_out(200, {"ok": True})
            if self.path == "/api/admin/password":
                set_password(body.get("id", ""), body.get("password", ""))
                tlog("admin", f"{self.user['name']} reset the password of {body.get('id', '')}")
                return self.json_out(200, {"ok": True})
            if self.path == "/api/config":
                return self.json_out(200, save_cfg(body))
            if self.path == "/api/ssh/connect":
                return self.json_out(200, ssh_connect(body.get("command", ""), body.get("password", "")))
            if self.path == "/api/ssh/disconnect":
                return self.json_out(200, ssh_disconnect())
            if self.path == "/api/skills":
                return self.json_out(200, save_skill(body.get("name", ""), body.get("description", ""), body.get("body", "")))
            if self.path == "/api/skills/delete":
                return self.json_out(200, delete_skill(body.get("name", "")))
            if self.path == "/api/models":
                return self.json_out(200, list_models(body.get("kind", "chat"), body["provider"], body.get("cfg", {})))
            self.json_out(404, {"error": "not found"})
        except Exception as e:
            self.json_out(500, {"error": str(e)})


if __name__ == "__main__":
    HOST = os.environ.get("HOST", "0.0.0.0")   # 0.0.0.0 = reachable from the network; 127.0.0.1 = this computer only
    srv = ThreadingHTTPServer((HOST, PORT), Handler)
    print("Agent Studio is running", flush=True)
    print(f"  This computer: http://127.0.0.1:{PORT}")
    if HOST not in ("127.0.0.1", "localhost"):
        for ip in lan_addresses():
            print(f"  Network:       http://{ip}:{PORT}", flush=True)
    print(f"  Workspace:     {WORKSPACE}")
    if not load_users():
        print("  First time: open the address above and create the admin account.", flush=True)
    print("  Activity from the web appears below.", flush=True)
    atexit.register(mcp_stop_all)
    srv.serve_forever()
